package communication;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.concurrent.CountDownLatch;

import net.sf.appia.jgcs.AppiaGroup;
import net.sf.appia.jgcs.AppiaProtocolFactory;
import net.sf.appia.jgcs.AppiaService;
import net.sf.jgcs.ClosedSessionException;
import net.sf.jgcs.DataSession;
import net.sf.jgcs.GroupConfiguration;
import net.sf.jgcs.JGCSException;
import net.sf.jgcs.Message;
import net.sf.jgcs.MessageListener;
import net.sf.jgcs.NotJoinedException;
import net.sf.jgcs.Protocol;
import net.sf.jgcs.Service;
import net.sf.jgcs.ServiceListener;
import net.sf.jgcs.UnsupportedServiceException;
import net.sf.jgcs.membership.BlockListener;
import net.sf.jgcs.membership.BlockSession;
import net.sf.jgcs.membership.Membership;
import net.sf.jgcs.membership.MembershipListener;

/**
 * Application to take numbers on the atomic broadcast times.
 */
public class RoundTripNumbers 
implements MessageListener, MembershipListener, BlockListener, ServiceListener, Runnable {
	private BlockSession control;
	private DataSession data;
	private Service uniform = new AppiaService("uniform_total_order");
	private Service regular = new AppiaService("regular_total_order");
	private Service sendService = new AppiaService("vsc+total+services");
	private int numMachines, numMessages, id, localID, frequency;
	private CountDownLatch latch = new CountDownLatch(1);
	private CountDownLatch finish;

	public RoundTripNumbers(String configFile, int numMachines, int numMessages, int freq) 
	throws JGCSException, IOException {
		this.numMachines = numMachines;
		this.numMessages = numMessages;
		this.frequency = freq;
		this.finish = new CountDownLatch(numMachines*numMessages);
		AppiaProtocolFactory pf = new AppiaProtocolFactory();
		Protocol p = pf.createProtocol();
		
		GroupConfiguration g = new AppiaGroup();
		((AppiaGroup)g).setConfigFileName(configFile);
		((AppiaGroup)g).setGroupName("NumbersGroup");
		this.control = (BlockSession) p.openControlSession(g);
		this.data = p.openDataSession(g);

		data.setMessageListener(this);
		data.setServiceListener(this);
		control.setMembershipListener(this);
		control.setBlockListener(this);
	}

	public Object onMessage(Message msg) {
		ByteArrayInputStream in = new ByteArrayInputStream(msg.getPayload());
		MessageID msgID = null;
		try {
			ObjectInputStream stream = new ObjectInputStream(in);
			msgID = (MessageID) stream.readObject();
			RoundtripStats.optimisticDeliver(msgID);
		} catch (IOException e) {
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
		return msgID;
	}

	public void onServiceEnsured(Object cookie, Service service) {
		try {
			if(service.compare(uniform)>=0){
				MessageID msgID = (MessageID) cookie;
				RoundtripStats.finalDeliver(msgID);
				finish.countDown();
				
			}
			else if(service.compare(regular)>=0){
				MessageID msgID = (MessageID) cookie;
				RoundtripStats.regularDeliver(msgID);				
			}
		} catch (UnsupportedServiceException e) {
			e.printStackTrace();
		}
	}

	public void onExcluded() {
		System.out.println("-- REMOVED from group.");
	}
	
	public void onMembershipChange() {
		try {
			Membership membership = control.getMembership();
			System.out.println("-- NEW MEMBERSHIP: " + membership);
			if(membership.getMembershipList().size() == numMachines)
				latch.countDown();
		} catch (NotJoinedException e) {
			e.printStackTrace();
			data.close();
		}
	}

	public void onBlock() {
		try {
			control.blockOk();
		} catch (JGCSException e) {
			e.printStackTrace();
		}
	}

	public void run() {
		try {
			// join the group
			control.join();
			// wait for all the members
			latch.await();
			// create and launch all the threads
			RoundtripStats.begin();
			
			for(int i=0; i<numMessages; i++){
				try {
					int proc = control.getMembership().getLocalRank();
					MessageID msgID = new MessageID(proc,id,localID++);
					sendMessage(msgID);
					Thread.sleep(frequency);
				} catch (NotJoinedException e1) {
					e1.printStackTrace();
				} catch (ClosedSessionException e) {
					e.printStackTrace();
				} catch (UnsupportedServiceException e) {
					e.printStackTrace();
				} catch (IOException e) {
					e.printStackTrace();
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
			}

			
			// wait for the threads to finish
			finish.await();
			RoundtripStats.end();
		} catch (ClosedSessionException e) {
			e.printStackTrace();
		} catch (JGCSException e) {
			e.printStackTrace();
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}

	private void sendMessage(MessageID msgID) throws IOException{
		ByteArrayOutputStream out = new ByteArrayOutputStream();
		ObjectOutputStream stream = new ObjectOutputStream(out);
		stream.writeObject(msgID);
		stream.close();
		out.close();
		Message msg = data.createMessage();
		msg.setPayload(out.toByteArray());
		Stats.sendMessage(msgID);
		data.multicast(msg, sendService, null);

	}
	
	public static void main(String[] args) {
		if(args.length != 4){
			System.err.println("Usage: java "+RoundTripNumbers.class.getName()+
					" <xml_config> <num_processes> <num_messages> <frequency(ms)>");
			System.exit(-1);
		}
		try {
			int machines=Integer.parseInt(args[1]); 
			int messages=Integer.parseInt(args[2]);
			int frequency = Integer.parseInt(args[3]);
			Runnable test = new RoundTripNumbers(args[0], machines, messages, frequency);
			test.run();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}
