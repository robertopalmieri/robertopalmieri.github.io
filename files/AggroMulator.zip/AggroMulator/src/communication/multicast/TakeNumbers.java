package communication.multicast;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.SocketAddress;
import java.util.concurrent.CountDownLatch;

import net.sf.jgcs.ClosedSessionException;
import net.sf.jgcs.ControlListener;
import net.sf.jgcs.ControlSession;
import net.sf.jgcs.DataSession;
import net.sf.jgcs.GroupConfiguration;
import net.sf.jgcs.JGCSException;
import net.sf.jgcs.Message;
import net.sf.jgcs.MessageListener;
import net.sf.jgcs.Protocol;
import net.sf.jgcs.ProtocolFactory;
import net.sf.jgcs.Service;
import net.sf.jgcs.ip.IpGroup;
import net.sf.jgcs.ip.IpProtocolFactory;
import net.sf.jgcs.ip.IpService;

/**
 * Application to take numbers on the multicast times.
 */
public class TakeNumbers 
implements MessageListener, ControlListener, Runnable {
	private ControlSession control;
	private DataSession data;
	private Service send = new IpService("1");
	private int receivedMessages=0, numMessages;
	private final int messagesToReceive;
	private int frequency, numGroupMembers=0, localID=0, hostID;
	private boolean starter;
	private CountDownLatch init = new CountDownLatch(1);
	private CountDownLatch finish = new CountDownLatch(1);

	public TakeNumbers(String group, int numMachines, int numMessages, int freq, int host, boolean st) 
	throws JGCSException, IOException {
		this.messagesToReceive = numMessages*numMachines;
		this.numMessages = numMessages;
		this.frequency = freq;
		this.starter = st;
		this.hostID = host;
		ProtocolFactory pf = new IpProtocolFactory();
		Protocol p = pf.createProtocol();
		
		GroupConfiguration g = new IpGroup(group);
		this.control = p.openControlSession(g);
		this.data = p.openDataSession(g);

		data.setMessageListener(this);
		control.setControlListener(this);
	}

	public Object onMessage(Message msg) {
		ByteArrayInputStream in = new ByteArrayInputStream(msg.getPayload());
		Object msgObj = null;
		try {
			ObjectInputStream stream = new ObjectInputStream(in);
			msgObj = stream.readObject();
			if(msgObj instanceof PreparedMessage){
				init.countDown();
			}
			else if(msgObj instanceof MessageID){
				MulticastStats.finalDeliver((MessageID) msgObj);
				if(++receivedMessages >= (messagesToReceive*0.75)){
					finish.countDown();
				}
			}
			else{
				System.err.println("Received unknown message: "+msgObj+" from: "+msg.getSenderAddress());
			}
		} catch (IOException e) {
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
		return null;
	}

	public void onFailed(SocketAddress arg0) {
		numGroupMembers--;
		System.out.println("-- FAILED MEMBER: " + arg0);
	}

	public void onJoin(SocketAddress arg0) {
		numGroupMembers++;
		System.out.println("-- JOINED MEMBER: " + arg0);
//		if(numGroupMembers == numMachines)
//			init.countDown();
	}

	public void onLeave(SocketAddress arg0) {
		numGroupMembers--;
		System.out.println("-- LEAVED MEMBER: " + arg0);
	}
	
	public void run() {
		try {
			// join the group
			control.join();
			// wait for all the members
			if(starter){
				ByteArrayOutputStream out = new ByteArrayOutputStream();
				ObjectOutputStream stream = new ObjectOutputStream(out);
				PreparedMessage prepareMsg = new PreparedMessage(control.getLocalAddress());
				stream.writeObject(prepareMsg);
				stream.close();
				out.close();
				Message prepare = data.createMessage();
				prepare.setPayload(out.toByteArray());
				data.multicast(prepare, send, null);
			}
			init.await();
			// create and launch all the threads
			MulticastStats.begin();

			for(int i=0; i<numMessages; i++){
				ByteArrayOutputStream out = new ByteArrayOutputStream();
				ObjectOutputStream stream = new ObjectOutputStream(out);
				MessageID msgID = new MessageID(hostID,localID++);
				stream.writeObject(msgID);
				stream.close();
				out.close();
				Message msg = data.createMessage();
				msg.setPayload(out.toByteArray());
				MulticastStats.sendMessage(msgID);
				data.multicast(msg, send, null);
				Thread.sleep(frequency);
			}
			// wait for the threads to finish
			finish.await();
			// sleep 30 secs just to be sure...
			MulticastStats.end();
		} catch (ClosedSessionException e) {
			e.printStackTrace();
		} catch (JGCSException e) {
			e.printStackTrace();
		} catch (InterruptedException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public static void main(String[] args) {
		if(args.length != 5){
			System.err.println("Usage: java "+TakeNumbers.class.getName()+
					" <IP:port> <num_processes> <num_messages> <frequency(millis)> <process_id> <starter>");
			System.exit(-1);
		}
		try {
			int machines=Integer.parseInt(args[1]); 
			int messages=Integer.parseInt(args[2]);
			int frequency = Integer.parseInt(args[3]);
			int id = Integer.parseInt(args[4]);
			boolean starter = Boolean.parseBoolean(args[5]);
			Runnable test = new TakeNumbers(args[0], machines, messages, frequency, id, starter);
			test.run();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}
