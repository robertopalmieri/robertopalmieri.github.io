package communication.multicast;

import java.io.PrintStream;

public class MulticastStats {
	
	private static PrintStream log = System.out;
	
	private MulticastStats(){}
	
	public static void begin(){
		log.println("BeginSimulation");
	}

	public static void end(){
		log.println("EndSimulation");
	}

	public static void sendMessage(MessageID msg){
		log.println("send "+msg.toString()+" "+System.nanoTime());
	}
	
	public static void optimisticDeliver(MessageID msg){
		log.println("deliverOPT "+msg.toString()+" "+System.nanoTime());
	}

	public static void finalDeliver(MessageID msg){
		log.println("deliverFinal "+msg.toString()+" "+System.nanoTime());
	}

}
