package communication.multicast;

import java.io.Externalizable;
import java.io.IOException;
import java.io.ObjectInput;
import java.io.ObjectOutput;
import java.net.SocketAddress;

public class PreparedMessage implements Externalizable{
	private SocketAddress address;
	
	public PreparedMessage(){		
	}
	
	public PreparedMessage(SocketAddress addr){
		address = addr;
	}
	
	/**
	 * @return the address
	 */
	public SocketAddress getAddress() {
		return address;
	}

	public void readExternal(ObjectInput in) throws IOException,
			ClassNotFoundException {
		address = (SocketAddress) in.readObject();
	}

	public void writeExternal(ObjectOutput out) throws IOException {
		out.writeObject(address);
	}
	
	@Override
	public String toString(){
		return "Prepared: "+address;
	}
	
}

