package communication;

import java.io.Externalizable;
import java.io.IOException;
import java.io.ObjectInput;
import java.io.ObjectOutput;

public class MessageID implements Externalizable{
	private int proc, thread, local;
	
	public MessageID(){
		
	}
	
	public MessageID(int p, int t, int l){
		proc = p;
		thread = t;
		local = l;
	}
	
	/**
	 * @return the proc
	 */
	public int getProc() {
		return proc;
	}

	/**
	 * @return the thread
	 */
	public int getThread() {
		return thread;
	}

	public void readExternal(ObjectInput in) throws IOException,
			ClassNotFoundException {
		proc = in.readInt();
		thread = in.readInt();
		local = in.readInt();
	}

	public void writeExternal(ObjectOutput out) throws IOException {
		out.writeInt(proc);
		out.writeInt(thread);
		out.writeInt(local);
	}
	
	@Override
	public String toString(){
		return proc+":"+thread+":"+local;
	}
	
//	@Override
//	public boolean equals(Object o){
//		if(o instanceof MessageID){
//			MessageID other = (MessageID)o;
//			return proc == other.proc && thread == other.thread && local == other.local;
//		}
//		return false;
//	}
//	
//	@Override
//	public int hashCode(){
//		return proc ^ thread ^ local;
//	}
	
}
