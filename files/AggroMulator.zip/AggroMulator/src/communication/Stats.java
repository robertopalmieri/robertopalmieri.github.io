package communication;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.PrintStream;
import java.net.URL;
import java.util.Properties;

public class Stats {
	
	private static PrintStream logSend, logSpont, logRegular, logFinal;
	private static String propsFile = "/messageslog.properties";
	private static Properties props = null;
	private static boolean booted = false;
	
	private Stats(){}

	private static void readProperties() throws IOException{
		props = new Properties();
		URL props_url = Stats.class.getResource(propsFile);
		if(props_url == null)
			throw new IOException("Could not find properties file: "+propsFile);
		InputStream is = props_url.openStream();
		props.load(is);
		is.close();
	}
	
	public static void boot(String prefix){
		if(booted)
			return;
		System.out.println("Booting loggers");
		try {
			readProperties();
			System.out.println("Opening file: "+prefix+"-"+props.getProperty("file_send"));
			logSend = new PrintStream(prefix+"-"+props.getProperty("file_send"));
			logSpont = new PrintStream(prefix+"-"+props.getProperty("file_spont"));
			logRegular = new PrintStream(prefix+"-"+props.getProperty("file_regular"));
			logFinal = new PrintStream(prefix+"-"+props.getProperty("file_final"));
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		booted = true;
	}
	
	public static void sendMessage(MessageID msg){
		logSend.println(msg.toString()+" "+System.nanoTime());
	}
	
	public static void networkDeliver(MessageID msg){
		logSpont.println(msg.toString()+" "+System.nanoTime());
	}
	
	public static void regularDeliver(MessageID msg){
		logRegular.println(msg.toString()+" "+System.nanoTime());
	}

	public static void finalDeliver(MessageID msg){
		logFinal.println(msg.toString()+" "+System.nanoTime());
	}
	
	public static void end(){
		logSpont.close();
		logRegular.close();
		logFinal.close();
	}

}
