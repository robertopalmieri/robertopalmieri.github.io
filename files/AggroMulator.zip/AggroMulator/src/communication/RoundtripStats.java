package communication;

import java.io.PrintStream;
import java.util.HashMap;
import java.util.Map;

public class RoundtripStats {
	
	private static PrintStream log = System.out;
	private Map<MessageID, Times> map = new HashMap<MessageID, Times>();
	private static RoundtripStats stats = new RoundtripStats();
	
	private RoundtripStats(){}
	
	public static void begin(){
		log.println("BeginSimulation");
		log.println("MessageID\toptimistic\tregular\tuniform");
	}

	public static void end(){
		log.println("EndSimulation");
	}

	public static void sendMessage(MessageID msg){
		stats.map.put(msg, new Times(System.nanoTime()));
	}
	
	public static void optimisticDeliver(MessageID msg){
		Times t = stats.map.get(msg);
		if(t != null){
			t.optimistic = System.nanoTime();
			stats.map.put(msg, t);
		}
	}

	public static void regularDeliver(MessageID msg){
		Times t = stats.map.get(msg);
		if(t != null){
			t.regular = System.nanoTime();
			stats.map.put(msg, t);
		}
	}
	
	public static void finalDeliver(MessageID msg){
		Times t = stats.map.remove(msg);
		if(t != null){
			t.uniform = System.nanoTime();
			long opt = t.optimistic-t.send;
			long reg = t.regular-t.optimistic;
			long unif = t.uniform-t.regular;
			log.println(msg.toString()+"\t"+opt+"\t"+reg+"\t"+unif);
		}
	}

}

class Times {
	long send,optimistic,regular,uniform;
	
	Times(){}
	
	Times(long s){
		send=s;
	}
}
