package communication;

public class Parser {

	private Parser(){}
	
	public static int byteArrayToInt(byte[] array, int offset){
		int ch1 = array[offset+0] & 0xFF;
		int ch2 = array[offset+1] & 0xFF;
		int ch3 = array[offset+2] & 0xFF;
		int ch4 = array[offset+3] & 0xFF;
		return ((ch1 << 24) + (ch2 << 16) + (ch3 << 8) + (ch4 << 0));
	}
	
	/**
	 * 
	 * @param i
	 * @param array
	 * @param offset
	 * @return the number of bytes written
	 */
	public static int intToByteArray(int i, byte[] array, int offset){
		array[offset + 0] = (byte) ((i >>> 24) & 0xFF);
		array[offset + 1] = (byte) ((i >>> 16) & 0xFF);
		array[offset + 2] = (byte) ((i >>> 8) & 0xFF);
		array[offset + 3] = (byte) ((i >>> 0) & 0xFF);
		return 4;
	}
	
	public static String byteArrayToString(byte[] array, int offset){
		
		int ch1 = array[offset + 0] & 0xFF;
		int ch2 = array[offset + 1] & 0xFF;
		int utflen = (ch1 << 8) + (ch2 << 0);
		
		char str[] = new char[utflen];
		int c, char2, char3;
		int count = 0;
		int strlen = 0;
		
		while (count < utflen) {
			c = (int) array[offset + count] & 0xff;
			switch (c >> 4) {
			case 0 :
			case 1 :
			case 2 :
			case 3 :
			case 4 :
			case 5 :
			case 6 :
			case 7 :
				/* 0xxxxxxx*/
				count++;
				str[strlen++] = (char) c;
				break;
			case 12 :
			case 13 :
				/* 110x xxxx   10xx xxxx*/
				count += 2;
				char2 = (int) array[offset + count - 1];
				str[strlen++] = (char) (((c & 0x1F) << 6) | (char2 & 0x3F));
				break;
			case 14 :
				/* 1110 xxxx  10xx xxxx  10xx xxxx */
				count += 3;
				char2 = (int) array[offset + count - 2];
				char3 = (int) array[offset + count - 1];
				str[strlen++] =
					(char) (((c & 0x0F) << 12) | ((char2 & 0x3F) << 6) | ((char3 & 0x3F) << 0));
				break;
			default:
				//ERROR
			}
		}
		return new String(str, 0, strlen);
	}
	
	/**
	 * 
	 * @param str
	 * @param array
	 * @param offset
	 * @return the number of bytes written
	 */
	public static int stringToByteArray(String str,byte[] array, int offset){
		int strlen = str.length();
		int utflen = 0;
		char[] charr = new char[strlen];
		int c, count = 0;
		
		str.getChars(0, strlen, charr, 0);
		
		for (int i = 0; i < strlen; i++) {
			c = charr[i];
			if ((c >= 0x0001) && (c <= 0x007F)) {
				utflen++;
			} else if (c > 0x07FF) {
				utflen += 3;
			} else {
				utflen += 2;
			}
		}
		
		array[offset + count++] = (byte) ((utflen >>> 8) & 0xFF);
		array[offset + count++] = (byte) ((utflen >>> 0) & 0xFF);
		for (int i = 0; i < strlen; i++) {
			c = charr[i];
			if ((c >= 0x0001) && (c <= 0x007F)) {
				array[offset + count++] = (byte) c;
			} else if (c > 0x07FF) {
				array[offset + count++] = (byte) (0xE0 | ((c >> 12) & 0x0F));
				array[offset + count++] = (byte) (0x80 | ((c >> 6) & 0x3F));
				array[offset + count++] = (byte) (0x80 | ((c >> 0) & 0x3F));
			} else {
				array[offset + count++] = (byte) (0xC0 | ((c >> 6) & 0x1F));
				array[offset + count] = (byte) (0x80 | ((c >> 0) & 0x3F));
			}
		}
		return count;
	}
}
