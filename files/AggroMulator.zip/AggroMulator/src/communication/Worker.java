package communication;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.util.concurrent.Semaphore;

import net.sf.appia.jgcs.AppiaService;
import net.sf.jgcs.ClosedSessionException;
import net.sf.jgcs.DataSession;
import net.sf.jgcs.Message;
import net.sf.jgcs.NotJoinedException;
import net.sf.jgcs.Service;
import net.sf.jgcs.UnsupportedServiceException;
import net.sf.jgcs.membership.MembershipSession;

public class Worker implements Runnable {

	private DataSession data;
	private MembershipSession membershipSession;
	private int id, numMessages;
	private int frequency;
	private int localID=0;
	private Semaphore semaphore;
	private Service sendService = new AppiaService("vsc+total+services");

	
	public Worker(DataSession data, MembershipSession membership,
			int id, int numMessages, int freq){
		this.data = data;
		this.id = id;
		this.numMessages = numMessages;
		this.frequency = freq;
		this.semaphore = new Semaphore(1);
		this.membershipSession = membership;
	}
	
	public void releaseSemaphore(){
		semaphore.release();
	}
	
	public void run() {
		System.out.println("Started thread. Sending "+numMessages+" messages.");
		for(int i=0; i<numMessages; i++){
			try {
				ByteArrayOutputStream out = new ByteArrayOutputStream();
				ObjectOutputStream stream = new ObjectOutputStream(out);
				int proc = membershipSession.getMembership().getLocalRank();
				MessageID msgID = new MessageID(proc,id,localID++);
				stream.writeObject(msgID);
				stream.close();
				out.close();
				Message msg = data.createMessage();
				msg.setPayload(out.toByteArray());
				Stats.sendMessage(msgID);
				data.multicast(msg, sendService, null);
				Thread.sleep(frequency);
			} catch (NotJoinedException e1) {
				e1.printStackTrace();
			} catch (ClosedSessionException e) {
				e.printStackTrace();
			} catch (UnsupportedServiceException e) {
				e.printStackTrace();
			} catch (IOException e) {
				e.printStackTrace();
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
		System.out.println("Done.");
	}

}
