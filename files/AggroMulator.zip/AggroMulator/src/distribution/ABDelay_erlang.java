package distribution;

import java.io.IOException;

import javasim.PropertyReader;
import arjuna.JavaSim.Distributions.ErlangStream;
import arjuna.JavaSim.Distributions.RandomStream;

public class ABDelay_erlang extends ABDelay{
	private final double abcastFinalTime = PropertyReader.getDouble("abcast_final_time");
	private final double stdAbcastFinalTime = PropertyReader.getDouble("std_abcast_final_time");
	private final double abcastOptimisticTime = PropertyReader.getDouble("abcast_optimistic_time");
	private final double stdAastOptimisticTime = PropertyReader.getDouble("std_abcast_optimistic_time");
	private RandomStream erlangAbcastFinalTime;
	private RandomStream erlangAbcastOptTime;
	
	public ABDelay_erlang() {
		erlangAbcastFinalTime = new ErlangStream(abcastFinalTime,stdAbcastFinalTime);
		erlangAbcastOptTime = new ErlangStream(abcastOptimisticTime,stdAastOptimisticTime);
	}

	public double getFinalDeliveryTime() {
		double ftime = 0;
		try {
			ftime = erlangAbcastFinalTime.getNumber();
		} catch (ArithmeticException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		return ftime;
	}
	
	public double getOptDeliveryTime() {
		double otime = 0;
		try {
			otime = erlangAbcastOptTime.getNumber();
		} catch (ArithmeticException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		return otime;
	}

	public double getSendingTime() {
		return sendingTime;
	}

	@Override
	public String getMsgId() {
		// TODO Auto-generated method stub
		return null;
	}
	
}
