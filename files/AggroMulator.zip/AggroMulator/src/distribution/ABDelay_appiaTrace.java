package distribution;

import javasim.traces.ABAppiaTraceLoader;
import javasim.traces.ABTraceLoader;

public class ABDelay_appiaTrace extends ABDelay{
	
	ABAppiaTraceLoader ab_loader = ABAppiaTraceLoader.instance();
	boolean already_got_final_delivery = false;
	boolean already_got_opt_delivery = false;
	boolean already_got_sending_time = false;
	boolean need_new_run = true;
	
	public double getFinalDeliveryTime() {
		if(need_new_run)
			 getNewRunFromTrace();
		already_got_final_delivery = true;
		if(already_got_opt_delivery)
			need_new_run = true;
		//return finalDelTime-sendingTime;
		return finalDelTime;
	}
	
	public double getOptDeliveryTime() {
		if(need_new_run)
			 getNewRunFromTrace();
		already_got_opt_delivery = true;
		if(already_got_final_delivery)
			need_new_run = true;
		//return optDelTime-sendingTime;
		return optDelTime;
	}
	private void getNewRunFromTrace(){
		ABDelay run = ab_loader.getNextABRun();
		sendingTime = run.sendingTime;
		optDelTime = run.optDelTime;
		finalDelTime = run.finalDelTime;
		msg_id = run.msg_id;
		need_new_run = false;
		already_got_final_delivery = false;
		already_got_opt_delivery = false;
	}

	public double getSendingTime() {
		//if(need_new_run)
		//	 getNewRunFromTrace();
		//already_got_sending_time = true;
		return sendingTime;
	}

	@Override
	public String getMsgId() {
		return msg_id;
	}
	
}
