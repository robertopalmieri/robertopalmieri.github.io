package distribution;

public abstract class ABDelay {
	public String msg_id;
	public double sendingTime;
	public double optDelTime;
	public double finalDelTime;
	
	public abstract double getOptDeliveryTime();
	public abstract double getFinalDeliveryTime();
	public abstract String getMsgId();
	public abstract double getSendingTime();
}
