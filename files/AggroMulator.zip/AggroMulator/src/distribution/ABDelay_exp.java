package distribution;

import java.io.IOException;

import javasim.PropertyReader;
import arjuna.JavaSim.Distributions.ExponentialStream;
import arjuna.JavaSim.Distributions.RandomStream;

public class ABDelay_exp extends ABDelay{
	private double abcastFinalTime;// = PropertyReader.getDouble("abcast_final_time");
	//private double stdAbcastFinalTime = PropertyReader.getDouble("std_abcast_final_time");
	private double abcastOptimisticTime;// = PropertyReader.getDouble("abcast_optimistic_time");
	//private double stdAastOptimisticTime = PropertyReader.getDouble("std_abcast_optimistic_time");
	private RandomStream expAbcastFinalTime;
	private RandomStream expAbcastOptTime;
	
	//public ABDelay_exp() {
	//	expAbcastFinalTime = new ExponentialStream(abcastFinalTime);
	//	expAbcastOptTime = new ExponentialStream(abcastOptimisticTime);
	//}
	
	public ABDelay_exp(int oab, int fab) {
		expAbcastFinalTime = new ExponentialStream(fab);
		expAbcastOptTime = new ExponentialStream(oab);
	}

	public double getFinalDeliveryTime() {
		double ftime = 0;
		try {
			ftime = expAbcastFinalTime.getNumber();
		} catch (ArithmeticException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		return ftime;
	}
	
	public double getOptDeliveryTime() {
		double otime = 0;
		try {
			otime = expAbcastOptTime.getNumber();
		} catch (ArithmeticException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		return otime;
	}

	public void setAbcastFinalTime(double abcastFinalTime) {
		this.abcastFinalTime = abcastFinalTime;
	}

	public void setAbcastOptimisticTime(double abcastOptimisticTime) {
		this.abcastOptimisticTime = abcastOptimisticTime;
	}
	public void reinstanceFistribution(){
		
	}

	public double getSendingTime() {
		return sendingTime;
	}

	@Override
	public String getMsgId() {
		// TODO Auto-generated method stub
		return null;
	}
}
