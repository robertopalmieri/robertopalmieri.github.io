package distribution;

import java.io.IOException;

import javasim.PropertyReader;
import arjuna.JavaSim.Distributions.RandomStream;
import arjuna.JavaSim.Distributions.UniformStream;

public class ABDelay_deterministic extends ABDelay{
	private final double abcastFinalTime = PropertyReader.getDouble("abcast_final_time");
	private final double abcastOptimisticTime = PropertyReader.getDouble("abcast_optimistic_time");
	private RandomStream uniformAbcastFinalTime;
	private RandomStream uniformAbcastOptTime;
	
	public ABDelay_deterministic() {
		uniformAbcastFinalTime = new UniformStream(abcastFinalTime,abcastFinalTime);
		uniformAbcastOptTime = new UniformStream(abcastOptimisticTime,abcastOptimisticTime);
	}

	public double getFinalDeliveryTime() {
		double ftime = 0;
		try {
			ftime = uniformAbcastFinalTime.getNumber();
		} catch (ArithmeticException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		return ftime;
	}
	
	public double getOptDeliveryTime() {
		double otime = 0;
		try {
			otime = uniformAbcastOptTime.getNumber();
		} catch (ArithmeticException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		return otime;
	}

	public double getSendingTime() {
		return sendingTime;
	}

	@Override
	public String getMsgId() {
		// TODO Auto-generated method stub
		return null;
	}
	
}
