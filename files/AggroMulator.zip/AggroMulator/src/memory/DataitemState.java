package memory;

public enum DataitemState {
	COMMITTED,
	WORKING,
	COMPLETED;
}
