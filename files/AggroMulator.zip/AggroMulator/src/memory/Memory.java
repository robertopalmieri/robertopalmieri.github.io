package memory;

import java.util.HashMap;
import java.util.Map;

public class Memory {
	private Map<String, Dataitem> memory;

	public Memory(int capacity) {
		memory = new HashMap<String, Dataitem>(capacity);
	}
	
	public Dataitem getDataitem(String diId){
		return memory.get(diId);
	}
	
	public void setWorkingDataitem(String diId){
		memory.get(diId).setState(DataitemState.WORKING);
	}
	
	public void setCompletedDataitem(String diId){
		memory.get(diId).setState(DataitemState.COMPLETED);
	}
	
	public void setCommittedDataitem(String diId){
		memory.get(diId).setState(DataitemState.COMMITTED);
	}
	public Dataitem initDataitem(String diId){
		Dataitem di = memory.get(diId);
		if(di == null){
			Dataitem new_di = new Dataitem(diId, DataitemState.COMMITTED, null);
			memory.put(diId, new_di);
			return new_di;
		}else{
			return di; 
		}
	}
	
	public boolean isWorking(String diId){
		return memory.get(diId).getState() == DataitemState.WORKING;
	}
	
	public boolean isCompleted(String diId){
		return memory.get(diId).getState() == DataitemState.COMPLETED;
	}
	
	public boolean isCommitted(String diId){
		return memory.get(diId).getState() == DataitemState.COMMITTED;
	}
}
