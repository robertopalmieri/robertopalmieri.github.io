package memory;

import javasim.Transaction;

public class Dataitem {
	private String id;
	private DataitemState state;
	private Transaction locker;
	private int lastWriterCommitted;
	
	public Dataitem(String id, DataitemState state, Transaction locker) {
		super();
		this.id = id;
		this.state = state;
		this.locker = locker;
		this.lastWriterCommitted = -1;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public DataitemState getState() {
		return state;
	}
	public void setState(DataitemState state) {
		this.state = state;
	}
	public Transaction getLocker() {
		return locker;
	}
	public void setLocker(Transaction locker) {
		this.locker = locker;
	}
	
	public int getLastWriterCommitted() {
		return lastWriterCommitted;
	}
	public void setLastWriterCommitted(int lastWriterCommitted) {
		this.lastWriterCommitted = lastWriterCommitted;
	}
	@Override
	public String toString() {
		return "DI:"+id+"[<"+state+";"+locker+">}";
	}
	
}
