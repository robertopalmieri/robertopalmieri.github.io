package createResultsFile;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.PrintStream;

public class createFile {
	public static void main(String[] args){
		BufferedReader reader;
		File directory = new File(args[0]);
		String out_file = args[0];
		try {
			File[] files = directory.listFiles();
			for (int i=0; i<files.length-1; i++) {
				reader = new BufferedReader(new FileReader(files[i]));
				while(true){
					String line = reader.readLine();
					if(line == null)
						break;
					try{
						String x = line.substring(0, line.indexOf(":"));
						System.out.println(x);
						if(x.equalsIgnoreCase("Mean Response Time")){
							String resp = line.substring(line.indexOf(":")+1);
							System.out.println(resp);
							File file_f = new File(out_file);
							FileOutputStream fileO = new FileOutputStream(file_f,true);
						    PrintStream Output = new PrintStream(fileO);
						    Output.println(resp);
						    break;
						}
					}catch(Exception ex){
						
					}
				}
		    }
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		
	}
}
