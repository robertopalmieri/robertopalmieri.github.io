package generatorABTrace;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.PrintStream;
import java.util.Random;

import sort.Sort;
import arjuna.JavaSim.Distributions.ExponentialStream;
import arjuna.JavaSim.Statistics.Variance;
import distribution.ABDelay_exp;

public class GenABTrace {
	//Sintassi corretta file_out lambda, oab, fab, numCampioni
	public static void main(String[] args) {
		try {
			double lambda = Double.parseDouble(args[1]);
			FileOutputStream fout;
			fout = new FileOutputStream (args[0]);
			FileOutputStream fout_onlyABtime;
			fout_onlyABtime = new FileOutputStream (args[0]+".sim");
		    PrintStream fwrite = new PrintStream(fout);
		    PrintStream fwrite_onlyABtime = new PrintStream(fout_onlyABtime);
		    long count_mgsId = 1;
		    long count_startMsg = 1;//in micro
		    long oab_time = 0;
		    long fab_time = 0;
		    long oab_time_cont = 0;
		    long fab_time_cont = 0;
		    //ABDelay_exp expDistribution = new ABDelay_exp(Integer.parseInt(args[2]),Integer.parseInt(args[3]));
		    //ExponentialStream expTTDistrb = new ExponentialStream((long)(1000000.0 /lambda));
		    ExponentialStream expTTDistrb = new ExponentialStream(lambda);
		    int numCampioni = Integer.parseInt(args[4]);
		    int numCampioniFixed = numCampioni;
		    //long[][] total = new long[numCampioni][3];//id-opt-final
		    Wrapper[] total = new Wrapper[numCampioniFixed]; 
		    //long[] totalFD = new long[numCampioni];
		    //long[] totalOD = new long[numCampioni];
		    int i=0;
		    double perc_confidenza = Double.parseDouble(args[5]);
		    double arg2 = Double.parseDouble(args[2]);
		    double arg3 = Double.parseDouble(args[3]);
		    double sigmaOAB = (perc_confidenza * (arg2))/100;
		    double sigmaFAB = (perc_confidenza*(arg3))/100;
		    Random rand = new Random(System.currentTimeMillis());
		    fwrite_onlyABtime.println("ID: 0 000 000 000");
		    while(numCampioni > 0){
		    	do{
		    		oab_time = (Math.round(rand.nextGaussian() * (sigmaOAB)) + (Integer.parseInt(args[2])));
		    	}while(oab_time<0);
		    	//oab_time = (Math.round(rand.nextGaussian() * (sigmaOAB)) + (Integer.parseInt(args[2])));
		    	oab_time_cont = oab_time;
		    	oab_time+=count_startMsg;
		    	long temp = 0; 
		    	do{
		    		temp = (Math.round(rand.nextGaussian() * (sigmaFAB)) + (Integer.parseInt(args[3])));
		    		fab_time_cont = temp;
		    		temp+=count_startMsg;
		    	}while(temp<oab_time);
		    	fab_time = temp;
		    	//totalFD[i] = fab_time;
			    //totalOD[i] = oab_time;
		    	total[i] = new Wrapper(count_mgsId, oab_time, fab_time);
		    	i++;
			    fwrite_onlyABtime.println("ID: "+count_mgsId+" 000 "+oab_time_cont+" "+fab_time_cont);
			    fwrite.println("ID: "+count_mgsId+" "+count_startMsg+" "+oab_time+" "+fab_time);
		    	count_mgsId++;
		    	count_startMsg+= expTTDistrb.getNumber();
		    	numCampioni--;
		    }
		    System.out.print("Finish generation!!!");
		    /*
		    for(int l=0;l<total.length;l++){
		    	fwrite.println(total[l].id+"\t"+total[l].ab);
		    }
		    */
		    Sort.quicksort(total);
		    /*
		    for(int l=0;l<total.length;l++){
		    	fwrite.println(total[l].id+"\t"+total[l].ab);
		    }
		    */
		    Variance numUnordered = new Variance();
		    Variance unorderedLenth = new Variance();
		    int len = 0;
		    
		    for(int k=0;k<numCampioniFixed;k++){
		    	for(int j=k-1;j>=0 && total[j].ab>total[k].opt ;j--)
			    	if(total[j].opt > total[k].opt)
			    		len++;
		    	if(len != 0){
		    		numUnordered.setValue(1);
		    		unorderedLenth.setValue(len);
		    	}
		    	len = 0;
		    }
		    fwrite.println("Time betw tx: "+lambda);
		    fwrite.println("Num Final Delivery unordered: "+(numUnordered.sum()/numCampioniFixed)*100+"%");
		    fwrite.println("Mean length of Final Delivery unordered: "+unorderedLenth.mean());
		    //for(int l=0;l<total.length;l++){
		    //	fwrite.println(total[l].id+"\t"+total[l].opt+"\t"+total[l].ab);
		    //}
		    fout.close();
		    fout_onlyABtime.close();
		    System.out.println("Num Final Delivery unordered: "+(numUnordered.sum()/numCampioniFixed)*100+"%");
		    System.out.println("Mean length of Final Delivery unordered: "+unorderedLenth.mean());
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}