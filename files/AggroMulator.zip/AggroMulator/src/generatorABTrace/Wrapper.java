package generatorABTrace;

public class Wrapper implements Comparable{
	public double id;
	public double opt;
	public double ab;
	
	public Wrapper(double id, double opt, double ab) {
		this.id = id;
		this.opt = opt;
		this.ab = ab;
	}
	
	public int compareTo(Object o) {
		Wrapper o2 = (Wrapper)o;
		Double l = new Double(ab);
		Double l2 = new Double(o2.ab);
		return l.compareTo(l2);
	}
}