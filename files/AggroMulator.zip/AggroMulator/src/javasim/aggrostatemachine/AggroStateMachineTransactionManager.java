package javasim.aggrostatemachine;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import javasim.CPU;
import javasim.Controller;
import javasim.DeliveryState;
import javasim.PropertyReader;
import javasim.TMOperation;
import javasim.Transaction;
import javasim.TransactionManager;
import javasim.TransactionState;
import javasim.TransactionalProcess;
import javasim.traces.TraceTransaction;
import javasim.traces.TracedOperation;
import javasim.traces.TracedOperation.TracedOperationType;
import memory.Dataitem;
import memory.DataitemState;

import org.apache.log4j.Logger;

import arjuna.JavaSim.Simulation.RestartException;
import arjuna.JavaSim.Simulation.SimulationException;

public class AggroStateMachineTransactionManager extends TransactionManager {
	private static String IpSender = PropertyReader.getString("IpSender");
	private final int typeOfABDistribution=PropertyReader.getInt("ABDistribution");
	
	Logger log = Logger.getLogger(AggroStateMachineTransactionManager.class);
	
	private CPU[] cpuPool;
	private ArrayList<Transaction> cpuQueue;
	private TransactionalProcess process;
	private boolean finished=false;
	private boolean isAggressive=PropertyReader.getBoolean("isAggressive");
	
	private List<Transaction> optDeliveredXAct;
	private List<Transaction> finalDeliveredXAct;
	
	public static Transaction Tc = {
		Tc = new TraceTransaction(-1,null,null,new ArrayList<TracedOperation>(),null);
		Tc.setDeliveryState(DeliveryState.FINAL_DELIVERED);
		Tc.setState(TransactionState.COMMITTED);
	};
	
	public AggroStateMachineTransactionManager(){
		cpuQueue = new ArrayList<Transaction>();
		optDeliveredXAct = new ArrayList<Transaction>(); 
		finalDeliveredXAct = new ArrayList<Transaction>();
	}
	
	/* (non-Javadoc)
	 * @see javasim.TransactionManager#init(javasim.TransactionalProcess, int)
	 */
	public void init(TransactionalProcess proc, int numberOfCPUs){
		process = proc;
		cpuPool = new CPU[numberOfCPUs];
		for(int i=0; i<cpuPool.length; i++){
			cpuPool[i]=new CPU(this,i);
			try {
				cpuPool[i].Activate();
			} catch (SimulationException e) {
				e.printStackTrace();
			} catch (RestartException e) {}
		}		
	}
	
	public void run(){
		while(!finished){
			CPU cpu=null;
			//devo analizzarmi le optdelivrate e masnare in cpu quela delivered
			List<Transaction> xActsToActivate = getXActsToActivate();
			if(!xActsToActivate.isEmpty()){
				for(Transaction tx : xActsToActivate){
					tx.setState(TransactionState.ACTIVE);
					cpuQueue.add(tx);
					if(log.isDebugEnabled()){
						log.debug("cpuQueue.add() "+cpuQueue.size()+" at "+CurrentTime());
						log.debug("enqueued xact "+tx+" in CPU at "+CurrentTime());
					}
					Controller.cpuQueueSize.setValue(cpuQueue.size());
				}
			}
			Transaction tx=null;
			Iterator<Transaction> it = cpuQueue.iterator();
			while(it.hasNext() && (cpu=getAvailableCPU()) != null){
				tx = it.next();
				if(((Integer)tx.getXactID()).intValue() == 128)
					log.debug("");
				if(tx.getState() == TransactionState.ACTIVE){
					tx.setState(TransactionState.EXECUTING);
					if(log.isDebugEnabled())
						log.debug("delivering xact "+tx+" to "+cpu+" at "+CurrentTime());
					cpu.executeTransaction(tx);
				}
			}
			try {
				Cancel();
			} catch (RestartException e) {}
		}
	}

	private List<Transaction> getXActsToActivate() {
		//scandisco le tx opt deliverate cercando quelle no ancora processate
		ArrayList<Transaction> xActsToActivate = new ArrayList<Transaction>();
		for(Transaction tx : optDeliveredXAct){
			if(tx.getState() == TransactionState.DELIVERED)
				xActsToActivate.add(tx);
		}
		return xActsToActivate;
	}

	/* (non-Javadoc)
	 * @see javasim.TransactionManager#deliverExecutedTransaction(javasim.Transaction)
	 */
	public void deliverCompleteTransaction(Transaction tx) {
		if(tx.safe)
			log.debug("");
		cpuQueue.remove(tx);
		log.debug("cpuQueue.remove() "+cpuQueue.size()+" at "+CurrentTime());
		Controller.cpuQueueSize.setValue(cpuQueue.size());
		Controller.numberOfExcludedTransactions.setValue(1);
		tx.setState(TransactionState.EXECUTED);
		if(tx.getDeliveryState() == DeliveryState.COMMITTABLE){
			Controller.committedWhenComplete.setValue(1);
			commitTransaction(tx);
		}
		//devo attivare le transazioni in cpu che stanno in attesa di quel dataitem
		for(int c=0;c<cpuPool.length;c++){
			//if(cpuPool[c].isInWait()){
				try {
					cpuPool[c].Activate();
				} catch (SimulationException e) {
					e.printStackTrace();
				} catch (RestartException e) {
					e.printStackTrace();
				}
			//}
		}
		/*
		ArrayList<CPU> toReactivate = new ArrayList<CPU>();
		for(int c=0;c<cpuPool.length;c++){
			if(!tx.getCpu().equals(cpuPool[c]) && cpuPool[c].isBusy() && cpuPool[c].isInWait()){//isInWait migliora le performance ed evita che venga ritrovata la stessa cpu della transazione
				if(cpuPool[c].getCurrentOperation().getOp_type() == TracedOperationType.READ &&
						(AggroStateMachineTransactionManager.containsInTMOperations(tx.getWriteSet(), cpuPool[c].getCurrentOperation()))!=null){
					toReactivate.add(cpuPool[c]);
				}
			}
		}
		if(!toReactivate.isEmpty()){
			int pos=0;
			int i = 0;
			boolean reactivated = false;
			for(pos=0;pos<optDeliveredXAct.size();pos++)
				if(optDeliveredXAct.get(pos).equals(tx))
					break;
			//for(i=pos+1;!reactivated && i<optDeliveredXAct.size();i++){
			for(i=pos+1;i<optDeliveredXAct.size();i++){
				for(CPU cp : toReactivate)
					if(cp.getTransaction().equals(optDeliveredXAct.get(i))){
						try {
							cp.Activate();
							//reactivated = true;
							//break;
						} catch (SimulationException e) {
							e.printStackTrace();
						} catch (RestartException e) {
							e.printStackTrace();
						}
					}
			}
		}
		*/
		if(!optDeliveredXAct.isEmpty() || !cpuQueue.isEmpty())
			try {
				Activate();
			} catch (SimulationException e) {
				e.printStackTrace();
			} catch (RestartException e){
				e.printStackTrace();
			}
	}
	
	/* (non-Javadoc)
	 * @see javasim.TransactionManager#optDelivery(javasim.Transaction)
	 */
	public void optDelivery(Transaction tx) {
		tx.setState(TransactionState.DELIVERED);
		tx.setDeliveryState(DeliveryState.OPT_DELIVERED);
		//tx.setStatsBeginTime(CurrentTime());
		Controller.numOptdelivered.setValue(1);
		//ccQueue.enqueueTransaction(tx);
		optDeliveredXAct.add(tx);
		try {
			Activate();
		} catch (SimulationException e) {
			e.printStackTrace();
		} catch (RestartException e) {}
	}

	/* (non-Javadoc)
	 * @see javasim.TransactionManager#finalDelivery(javasim.Transaction)
	 */
	public void finalDelivery(Transaction nextXactToFinalDelivered) {
		if(((Integer)nextXactToFinalDelivered.getXactID()).intValue() == 8)
			log.debug("");
		if(nextXactToFinalDelivered.getState() == TransactionState.ABORTING)
			throw new RuntimeException("Transaction "+nextXactToFinalDelivered+" final deliver while aborting");
		Controller.numFinalDelivered.setValue(1);
		Transaction tx = optDeliveredXAct.get(0);
		if(!nextXactToFinalDelivered.equals(tx)){
			Controller.numOutOfOrder.setValue(1);
			log.debug("Fuoriordine nelle notifiche");
			//abortisco tutte le transazioni che mi precedono nella opt delivery ed eseguo in maniera safe
			boolean trovata = false;
			int i = 0;
			for(i=0;i<optDeliveredXAct.size();i++)
				if(optDeliveredXAct.get(i).equals(nextXactToFinalDelivered)){
					trovata = true;
					break;
				}
			if(trovata){
				Transaction actualTxToFinalDeliver = optDeliveredXAct.get(i);
				actualTxToFinalDeliver.setDeliveryState(DeliveryState.COMMITTABLE);
				//optDeliveredXAct.remove(actualTxToFinalDeliver);
				//finalDeliveredXAct.add(actualTxToFinalDeliver);
				
				ArrayList<Transaction> toAbort = new ArrayList<Transaction>();
				//prima abortivo tutto il trenino
				for(int j=0;j<i;j++)
					toAbort.add(optDeliveredXAct.get(j));
				//devo farla rieseguire in maniera safe(ovvero la abortisco e la reinserisco in cpu(non essendo + opt-delivered esegue safe cos� legge solo committed)
				toAbort.add(actualTxToFinalDeliver );
				abortTransactions(toAbort);
			}else{
				throw new RuntimeException("Tx final delivered not in Opt-Delivered List");
			}
		}else{
			if(((Integer)tx.getXactID()).intValue() == 100)
				log.debug("");
			optDeliveredXAct.remove(tx);
			finalDeliveredXAct.add(tx);
			//tx.setDeliveryState(DeliveryState.FINAL_DELIVERED);
			tx.setDeliveryState(DeliveryState.COMMITTABLE);
			if(tx.getState() == TransactionState.EXECUTED){
				if(finalDeliveredXAct.get(0).getXactID() == tx.getXactID()){
					Controller.committedAtTOTime.setValue(1);
					commitTransaction(tx);
				}
			}else if(tx.getState() != TransactionState.EXECUTING && tx.getState() != TransactionState.ABORTING){
				tx.setState(TransactionState.ACTIVE);
				boolean inserito = false;
				for(int i=0;i<cpuQueue.size();i++){
					if(cpuQueue.get(i).getDeliveryState() != DeliveryState.COMMITTABLE){
						cpuQueue.add(i,tx);
						inserito = true;
						break;
					}
				}
				if(!inserito){
					cpuQueue.add(tx);
				}
			}else {
				log.debug("Wait for complete execution");
			}
		}
		try {
			Activate();
		} catch (SimulationException e) {
			e.printStackTrace();
		} catch (RestartException e) {
			e.printStackTrace();
		}
		
		
		
		
		
		/*
		if(tx.getState() == TransactionState.ABORTING){
			//log.info("Ficoooooo delivero una abortita che sta in CPU!!!!!");
			//return;
			for(int cp=0;cp<cpuPool.length;cp++){
				if(cpuPool[cp].isBusy() && cpuPool[cp].getTransaction().equals(tx)){
					log.debug("Ficoooooo delivero una abortita che sta in CPU!!!!!");
					//mi clono per eliminare la transazione dalla cpu
					tx = tx.cloneMe();
					tx.setState(TransactionState.DELIVERED);
					Controller.numAborted.setValue(1);
					break;
					//cpuPool[cp].setTransaction(null);
				}
			}
		}
		Controller.numFinalDelivered.setValue(1);
		tx.setDeliveryState(DeliveryState.COMMITTABLE);
		//Se la tx � nello stato executed, allora la posso committare(vuol dire che non conflittava)
		if(tx.getState() == TransactionState.EXECUTED){
			commitTransaction(tx);
		}else if(tx.getState() != TransactionState.EXECUTING){//Tx non � nello stato executed, quindi pu� essere in ordine o fuori ordine
			Transaction enqueuedXact = ccQueue.getNextPendingTransaction();
			if(enqueuedXact == null){
				log.debug("Received a final delivery of a transaction that is not enqueued any more! Xact was already aborted.");
				//throw new RuntimeException("Received a final delivery of a transaction that is not enqueued any more!!!");
				//return;
			}
			if(enqueuedXact!= null && !enqueuedXact.equals(tx)){
				//Se la tx non � la next pending transaction devo abortirla
				abortTransaction(enqueuedXact);
				Controller.numOutOfOrder.setValue(1);
				//Questo prima era fatto 
				List<Transaction> unordered = ccQueue.getUnorderedTransactions(tx);
				//Se unordered � vuota, allora la tx � in ordine. Altrimenti abortisco le precedenti
				int mean_aborts_for_each_abort = 0;
				for(Transaction ref : unordered){
					if(ccQueue.conflictWith(ref, tx)){
						log.debug("Abort of "+ref);
						mean_aborts_for_each_abort++;
						abortTransaction(ref);
					}
				}
				Controller.numAbortAfterReordering.setValue(mean_aborts_for_each_abort);
			}
			ccQueue.rescheduleTransactionOnTailOfCommittable(tx);
		}else{
			log.debug("Transaction final delivered while executing in CPU");
		}
		*/
	}
	
	private void commitTransaction(Transaction txtoopt){
		Integer n = (Integer)txtoopt.getXactID();
		if(n.intValue() == 101)
			log.debug("");
		if(Controller.numCommitted.sum() ==  24.0)
			log.debug("");
		boolean canCommit = false;
		ArrayList<Transaction> toRemoveFormFinalDelivered = new ArrayList<Transaction>();
		if(finalDeliveredXAct.get(0).equals(txtoopt)){
			canCommit = true;
		}
		if(canCommit){
			for(int i=0;i<finalDeliveredXAct.size();i++){
				if(finalDeliveredXAct.size() > 2)
					log.debug("");
				Transaction tx = finalDeliveredXAct.get(i);
				if(tx.getState() == TransactionState.EXECUTED){
					boolean validated = true;
					//itero sul writeset per dire che sono io che ho scritto la versione committed
					for(int k=0;k<tx.getReadSet().size();k++){
						TMOperation a  = tx.getReadSet().get(k);
						if((Integer)a.getReadFrom().getXactID() != a.getDi().getLastWriterCommitted()){
							//throw new RuntimeException("Committing transacion raed from not committed transacion");
							validated = false;
							break;
						}
					}
					if(validated){
						tx.commit();
						//la tolgo dalle final delivered per alleggerire la dimensione delle liste
						toRemoveFormFinalDelivered.add(tx);
						if(tx.getProcess().equals(process)){
							//tx.getSource().transactionFinished(tx);
							if(typeOfABDistribution == 3){
								//if(tx.msgId.equalsIgnoreCase(IpSender) && tx.getXactResponseTime() < 5000000){
								if(tx.msgId.equalsIgnoreCase(IpSender)){
									Controller.responseTime.setValue(tx.getXactResponseTime());
									Controller.lastRespTimeAcquired = tx.getXactResponseTime();
									if(tx.safe)
										Controller.safe.setValue(1);
									System.out.println(tx+"-"+(tx.getXactResponseTime()));
								}
							}else{
								Controller.responseTime.setValue(tx.getXactResponseTime());
								Controller.lastRespTimeAcquired = tx.getXactResponseTime();
								if(tx.safe)
									Controller.safe.setValue(1);
								System.out.println(tx+"-"+(tx.getXactResponseTime()));
							}
							//Stampa per la distribuzione dei tempi di risposta
							//System.out.println(tx.getXactID()+"\t"+tx.getExecutionTime()+"\t"+tx.getXactResponseTime());
						}
						Controller.numCommitted.setValue(1);
					}else{
						ArrayList<Transaction> arr = new ArrayList<Transaction>();
						arr.add(tx);
						tx.safe = true;
						abortTransactions(arr);
						break;
					}
				}else
					break;
			}
			for(Transaction t : toRemoveFormFinalDelivered){
				finalDeliveredXAct.remove(t);
				cpuQueue.remove(t);
			}
				
		}else{
			return;
		}
		
		/*
		if(!isAggressive){
			ccQueue.removeTransaction(tx);
			Controller.ccQueueSize.setValue(ccQueue.size());
			Controller.lockWaitTime.setValue(tx.getLockWaitTime());
			Controller.cpuWaitTime.setValue(tx.getCpuWaitTime());
			
			//if(log.isDebugEnabled())
				log.debug("Transaction "+tx+" committed.");
			tx.commit();
			if(tx.getProcess().equals(process)){
				//tx.getSource().transactionFinished(tx);
				Controller.responseTime.setValue(tx.getXactResponseTime());
				//Stampa per la distribuzione dei tempi di risposta
				//System.out.println(tx.getXactID()+"\t"+tx.getExecutionTime()+"\t"+tx.getXactResponseTime());
			}
			Controller.numCommitted.setValue(1);
			
		}else{//Aggressive
			tx.commit();
			if(log.isDebugEnabled())
				log.debug("Transaction "+tx+" committed.");
			if(tx.getProcess().equals(process)){
				//tx.getSource().transactionFinished(tx);
				Controller.responseTime.setValue(tx.getXactResponseTime());
				//System.out.println(tx.getXactID()+"\t"+tx.getExecutionTime()+"\t"+tx.getXactResponseTime());
			}
			Controller.numCommitted.setValue(1);
		}
		tx.clearReadWriteSet();
		*/
		//devo riattivare ma lo faccio prima per far partire la prossima transazione bloccata
		/*
		try {
			Activate();
		} catch (SimulationException e) {
			e.printStackTrace();
		} catch (RestartException e) {}
		*/
	}
	
	public void abortTransactions(List<Transaction> txs){
		for(Transaction tx : txs){
			if(tx.getState() == TransactionState.ABORTING)
				continue;
			//Cascading abort
			int pos = 0;
			Integer n = (Integer)tx.getXactID();
			if(n.intValue() == 128)
				log.debug("");
			List<Transaction> txs_to_abort = new ArrayList<Transaction>();
			for(int j=0;j<tx.getWriteSet().size();j++){
				for(pos=0;pos<optDeliveredXAct.size();pos++)
					if(optDeliveredXAct.get(pos).equals(tx))
						break;
				for(int i=pos+1;i<optDeliveredXAct.size();i++)
					if((AggroStateMachineTransactionManager.containsInTMOperations(optDeliveredXAct.get(i).getReadSet(), tx.getWriteSet().get(j))) != null){
						//questa � una vera e propria abort perch� la tx ha gi� letto qualcosa quindi � stat in CPU!!
						txs_to_abort.add(optDeliveredXAct.get(i));
					}
			}
			Controller.numAborted.setValue(1);
			tx.abort();
			//cpuQueue.remove(tx);
			TraceTransaction new_tx = null;
			try {
				new_tx = (TraceTransaction) ((TraceTransaction)tx).clone();
			}catch (CloneNotSupportedException e) {
				e.printStackTrace();
			}
			if(tx.getDeliveryState() == DeliveryState.OPT_DELIVERED){
				for(int i=0;i<cpuQueue.size();i++){
					if(cpuQueue.get(i).equals(tx)){
						cpuQueue.remove(i);
						cpuQueue.add(i,new_tx);
						new_tx.setState(TransactionState.ACTIVE);
						break;
					}
				}
				boolean trovato = false;
				for(int i=0;i<optDeliveredXAct.size();i++){
					if(optDeliveredXAct.get(i).equals(tx)){
						if(((Integer)tx.getXactID()).intValue() == 100)
							log.debug("");
						optDeliveredXAct.remove(i);
						optDeliveredXAct.add(i,new_tx);
						trovato = true;
						break;
					}
				}
				if(!trovato)
					throw new RuntimeException("Abortisco tx opt-delivered ma non presente nell'elenco");
			}else{
				log.debug("Abortisco tx che non � marcata come opt-deliverata");
				optDeliveredXAct.remove(new_tx);
				if(finalDeliveredXAct.contains(new_tx))
					finalDeliveredXAct.set(finalDeliveredXAct.indexOf(new_tx), new_tx);
				else
					finalDeliveredXAct.add(new_tx);
				new_tx.setState(TransactionState.ACTIVE);
				cpuQueue.remove(tx);
				//cpuQueue.add(0,new_tx);
				boolean inserito = false;
				for(int i=0;i<cpuQueue.size();i++){
					if(cpuQueue.get(i).getDeliveryState() != DeliveryState.COMMITTABLE){
						cpuQueue.add(i,new_tx);
						inserito = true;
						break;
					}
				}
				if(!inserito){
					cpuQueue.add(new_tx);
				}
			}
			if(!txs_to_abort.isEmpty())
				abortTransactions(txs_to_abort);
		}
		
		//la faccio dopo nella tx.abort()
		//tx.setState(TransactionState.ABORTING);
		/*
		if(tx.getState() == TransactionState.EXECUTING){
			try {
				tx.getCpu().Activate();
			} catch (SimulationException e) {
				e.printStackTrace();
			} catch (RestartException e) {
				e.printStackTrace();
			}
		}
		*/
		
	}

	
	/*
	 * gets an available CPU, or null if the CPUs are all busy
	 */
	private CPU getAvailableCPU(){
		for(int i=0; i<cpuPool.length; i++){
			if(!cpuPool[i].isBusy())
				return cpuPool[i];
		}
		return null;
	}
	
	/* (non-Javadoc)
	 * @see javasim.TransactionManager#finish()
	 */
	public void finish(){
		finished = true;
		try {
			for(int i=0; i<cpuPool.length; i++){
				cpuPool[i].terminate();
				if(cpuPool[i].idle())
					cpuPool[i].Activate();
			}
			this.terminate();
			if(this.idle())
				this.Activate();
		} catch (SimulationException e) {
			e.printStackTrace();
		} catch (RestartException e) {}
	}
	/* (non-Javadoc)
	 * @see javasim.TransactionManager#getProcess()
	 */
	public TransactionalProcess getProcess() {
		return process;
	}

	public List<Transaction> getOptDeliveredXAct() {
		return optDeliveredXAct;
	}

	public List<Transaction> getFinalDeliveredXAct() {
		return finalDeliveredXAct;
	}
	public static Dataitem containsInTMOperations(List<TMOperation> ops,TMOperation op){
		for(TMOperation t : ops){
			if(t.getDi().getId().equals(op.getDi().getId()))
				return t.getDi();
		}
		return null;
	}
}
