package javasim;

import java.util.List;

import memory.Dataitem;
import arjuna.JavaSim.Simulation.Scheduler;

/**
 * This class represents a transaction.
 * @author nuno
 *
 */
public abstract class Transaction implements Cloneable{
	private static String IpSender = PropertyReader.getString("IpSender");
	private Object xactID;
	private long globalOrder;
	private TransactionalSource source;
	private Sender process;
	private TransactionState state;
	private DeliveryState deliveryState;
	private double statsBeginTime=-1, statsCommitTime=-1;
	private CPU cpu;
	
	private double optDeliveryTime=-1, finalDeliveryTime=-1;
	private boolean optimistic;
	private double startProcessing = -1;
	public boolean safe;
	public String msgId;
	
	public Transaction(Object id, Sender proc, TransactionalSource sr){
		xactID=id;
		process = proc;
		source = sr;
		//memory = mem;
		state = TransactionState.STARTED;
		//statsBeginTime = Scheduler.CurrentTime();
		safe = false;
	}

	public abstract List<TMOperation> getReadSet();
	
	public abstract List<TMOperation> getWriteSet();
	
	public abstract void clearReadWriteSet();
	
	public abstract double getExecutionTime();
	
	public abstract void doCommit();
	
	/**
	 * gets the NEXT delivery time.
	 * @return
	 */
	public double getDeliveryTime(){
		return optimistic? optDeliveryTime : finalDeliveryTime;
	}
	
	/**
	 * sets both (optimistic and final) delivery times (the timestamp in the future when it should be delivered)
	 * @param opt
	 * @param fin
	 */
	public void setDeliveryTimes(double opt, double fin){
		optDeliveryTime = opt;
		finalDeliveryTime = fin;
	}
	
	public void execute(){
		state = TransactionState.EXECUTED;
	}
	
	public boolean commit(){
		//In ordigine committava i dataitems in memoria multiversioned
		//doCommit();
		for(int i=0;i<getWriteSet().size();i++){
			TMOperation a  = getWriteSet().get(i);
			a.getDi().setLastWriterCommitted((Integer)xactID);
		}
		
		state = TransactionState.COMMITTED;
		statsCommitTime=Scheduler.CurrentTime();
		//if(msgId.equalsIgnoreCase(IpSender) && getXactResponseTime() < 5000000){
			System.out.println(this+" Start "+statsBeginTime+"|Commit: "+statsCommitTime+"|RTime= "+(statsCommitTime-statsBeginTime));
		//}
		return true;
	}
	
	public void abort(){
		state = TransactionState.ABORTING;
		//statsCommitTime=Scheduler.CurrentTime();
	}
	
	//public VersionedMemory getMemory(){
	//	return memory;
	//}
	
	public TransactionalSource getSource(){
		return source;
	}
	
	public Sender getProcess(){
		return process;
	}
	
	public int getProcessID(){
		return process.getProcessID();
	}
	
	/**
	 * @return the state
	 */
	public TransactionState getState() {
		return state;
	}

	/**
	 * @param state the state to set
	 */
	public void setState(TransactionState state) {
		this.state = state;
	}

	public double getXactResponseTime(){
		if(statsBeginTime==-1 || statsCommitTime==-1)
			throw new RuntimeException("The stats of the xact were not set. Cannot call this before you commit.");
		return statsCommitTime-statsBeginTime;
	}

	public Transaction cloneMe(){
		try {
			return (Transaction) this.clone();
		} catch (CloneNotSupportedException e) {
			throw new RuntimeException("Clone of Transaction not supported",e);
		}
	}
	
	@Override
	public String toString(){
		return "XACT "+process.getProcessID()+":"+source.getSourceID()+":"+xactID+" - "+state;
	}
	
	@Override
	public boolean equals(Object o){
		if(o instanceof Transaction){
			Transaction t = (Transaction) o;
			return process.getProcessID()==t.process.getProcessID() && 
				source.getSourceID()==t.source.getSourceID() && xactID.equals(t.xactID);
		}
		return false;
	}
	
	@Override
	public int hashCode(){
		return process.getProcessID() ^ source.getSourceID() ^ xactID.hashCode();
	}

	/**
	 * @return the optimistic
	 */
	public boolean isOptimistic() {
		return optimistic;
	}

	/**
	 * @param optimistic the optimistic to set
	 */
	public void setOptimistic(boolean optimistic) {
		this.optimistic = optimistic;
	}

	/**
	 * @return the deliveryState
	 */
	public DeliveryState getDeliveryState() {
		return deliveryState;
	}

	/**
	 * @param deliveryState the deliveryState to set
	 */
	public void setDeliveryState(DeliveryState deliveryState) {
		this.deliveryState = deliveryState;
	}

	/**
	 * @return the cpu
	 */
	public CPU getCpu() {
		return cpu;
	}

	/**
	 * @param cpu the cpu to set
	 */
	public void setCpu(CPU cpu) {
		this.cpu = cpu;
	}

	public long getGlobalOrder() {
		return globalOrder;
	}

	public void setGlobalOrder(long globalOrder) {
		this.globalOrder = globalOrder;
	}


	/**
	 * @return the startProcessing
	 */
	public double getStartProcessing() {
		return startProcessing;
	}

	/**
	 * @param startProcessing the startProcessing to set
	 */
	public void setStartProcessing(double startProcessing) {
		this.startProcessing = startProcessing;
	}
	
	public void setStatsBeginTime(double statsBeginTime) {
		this.statsBeginTime = statsBeginTime;
	}
	
	public void setFinalDeliveryTime(double finalDeliveryTime) {
		this.finalDeliveryTime = finalDeliveryTime;
	}

	public Object getXactID() {
		return xactID;
	}
	
}
