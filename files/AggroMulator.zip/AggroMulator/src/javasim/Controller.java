package javasim;
import java.util.Random;

import org.apache.log4j.Logger;

import sort.Sort;
import arjuna.JavaSim.Simulation.RestartException;
import arjuna.JavaSim.Simulation.Scheduler;
import arjuna.JavaSim.Simulation.SimulationEntity;
import arjuna.JavaSim.Simulation.SimulationException;
import arjuna.JavaSim.Simulation.SimulationProcess;
import arjuna.JavaSim.Statistics.TimeVariance;
import arjuna.JavaSim.Statistics.Variance;

/**
 * the main controller of the simulation. It starts all the objects needed and 
 * collect numbers at the end.
 * @author nuno
 *
 */
public class Controller extends SimulationEntity {

	Logger log = Logger.getLogger(Controller.class);
	public static Network totalOrderNetwork;

	public static TimeVariance cpuQueueSize;
	public static Variance numDIWorking,numDIComplete,numDICommitted,responseTime,executionTxTime,numOptdelivered,numFinalDelivered,numCommitted,numAborted,numAbortAfterReordering,numOutOfOrder,lockWaitTime,cpuWaitTime,meanCpusUsage,finalDeliveryBeforeComplete,committedWhenComplete,committedAtTOTime,safe,numberOfExcludedTransactions,sizeOfTransactions;
	public static TimeVariance[] cpusUsage;
	public static double lastRespTimeAcquired = 0.0;
	
	private TransactionalProcess[] processes;
	private int finishedProcesses=0;

	public Controller() {
		cpuQueueSize = new TimeVariance();
		responseTime = new Variance();
		executionTxTime = new Variance();
		numOptdelivered = new Variance();
		numFinalDelivered = new Variance();
		numAborted = new Variance();
		numOutOfOrder = new Variance();
		numAbortAfterReordering = new Variance();
		numCommitted = new Variance();
		lockWaitTime = new Variance();
		cpuWaitTime = new Variance();
		meanCpusUsage = new Variance();
		finalDeliveryBeforeComplete = new Variance();
		committedWhenComplete = new Variance();
		committedAtTOTime = new Variance();
		safe = new Variance();
		numberOfExcludedTransactions = new Variance();
		sizeOfTransactions = new Variance();
		numDIWorking = new Variance();
		numDIComplete = new Variance();
		numDICommitted = new Variance();
		int numCPUs = PropertyReader.getInt("num_cpus");
		cpusUsage = new TimeVariance[numCPUs];
		
		for(int i=0;i<numCPUs;i++){
			cpusUsage[i] = new TimeVariance();
		}
	}

	public void run() {
		double simulationExecTime = PropertyReader.getDouble("simulation_execution_time");
		int numSources = PropertyReader.getInt("num_sources");
		int numCPUs = PropertyReader.getInt("num_cpus");
		int numProcesses = PropertyReader.getInt("num_processes");
		boolean deliverOptimistic=PropertyReader.getBoolean("deliver_optimistic");
		try{
			Class<? extends TransactionalSource> sourceClass = 
				(Class<? extends TransactionalSource>) Class.forName(PropertyReader.getString("source_class"));
			
			totalOrderNetwork = new Network("Total Order Network");
			totalOrderNetwork.Activate();
			
			processes = new TransactionalProcess[numProcesses];
			for(int i=0; i<processes.length; i++){
				processes[i] = new TransactionalProcess(i, numSources,sourceClass, numCPUs,totalOrderNetwork,this);
				processes[i].Activate();
			}
		} catch (SimulationException e) {
			e.printStackTrace();
		} catch (RestartException e) {
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
		
		try {
			Random randGC = new Random();
			Scheduler.startSimulation();
			System.out.println("started simulation");
			int numIterationBlocked = 0;
			double lastCommitted = 0;
			boolean simBlocked = false;
			while (CurrentTime() < simulationExecTime) {
			//while (true) {
				if(deliverOptimistic){
					//if(finishedProcesses != 0 && (numCommitted.sum() == numOptdelivered.sum()))
					if(lastCommitted == numCommitted.sum())
						numIterationBlocked++;
					//if(numIterationBlocked>5){
					//	simBlocked = true;
					//	break;
					//}
					lastCommitted = numCommitted.sum();
					if(finishedProcesses != 0 && (numCommitted.sum() == PropertyReader.getInt("total_transactions")))
					//if(finishedProcesses != 0 && (numFinalDelivered.sum() == numOptdelivered.sum()))
						break;
				}else{
					if(finishedProcesses != 0 && (numFinalDelivered.sum() == numCommitted.sum()))
						break;
				}
				System.out.println("% Committed Transactions: "+numCommitted.sum()/((PropertyReader.getInt("total_transactions")))*100+" %");
				System.out.println("Mean Response Time:"+responseTime.mean());
				
				log.debug("Num OptDelivered:"+numOptdelivered.sum());
				log.debug("Num Completed:"+numberOfExcludedTransactions.sum());
				log.debug("Num FinalDelivered:"+numFinalDelivered.sum());
				log.debug("Num Abort after Reordering:"+numAbortAfterReordering.sum());
				log.debug("Num Committed:"+numCommitted.sum());
				log.debug("Number of Aborted transactions: "+numAborted.sum());
				log.debug("Number of Aborted transactions: "+numCommitted.mean());
				log.debug("Number of Working path access: "+numDIWorking.sum());
				log.debug("Number of Completed path access: "+numDIComplete.sum());
				log.debug("Number of Committed path access: "+numDICommitted.sum());
				
				Hold(1000000000);
				if(randGC.nextInt(100) <= 20){
					System.gc();
				//	log.debug("Call GC");
				}
			}
			System.out.println("Total simulation time: "+CurrentTime());
			Scheduler.stopSimulation();
			System.out.println("**** SETTINGS ****");
			System.out.println("Trace: "+PropertyReader.getString("trace_file"));
			System.out.println("AB Type "+PropertyReader.getInt("ABDistribution")+" AB Trace: "+PropertyReader.getString("AB_trace_file"));
			System.out.println("TransactionManager: "+PropertyReader.getString("protocol_manager"));
			System.out.println("Trace in micro: "+PropertyReader.getBoolean("tracciaMicro"));
			System.out.println("Processes: "+numProcesses+";CPU: "+numCPUs);
			System.out.println("Sources: "+numSources);
			System.out.println("Inter time: "+PropertyReader.getInt("transactions_rate"));
			System.out.println("Rate: "+1000000/PropertyReader.getInt("transactions_rate")+"tx/sec");
			System.out.println("OAB: "+PropertyReader.getDouble("abcast_optimistic_time"));
			System.out.println("FAB: "+PropertyReader.getDouble("abcast_final_time"));
			System.out.println("Aggressive:"+PropertyReader.getBoolean("isAggressive"));
			System.out.println("**** SNAPSHOT AT END OF RUN ****");
			System.out.println("Mean Response Time:"+responseTime.mean());
			System.out.println("StdDev. Response Time:"+responseTime.stdDev());
			System.out.println("Mean CPU Queue size:"+cpuQueueSize.timeAverage());
			System.out.println("Max CPU Queue size:"+cpuQueueSize.max());
			System.out.println("Media CPU Queue size:"+cpuQueueSize.timeAverage());
			System.out.println("Number of samples of CPU Queue size:"+cpuQueueSize.numberOfSamples());
			System.out.println("StdDev. CPU Queue size:"+cpuQueueSize.stdDev());
			System.out.println("Mean lock wait time:"+lockWaitTime.mean());
			System.out.println("StdDev.lock wait time:"+lockWaitTime.stdDev());
			System.out.println("Mean cpu wait time:"+cpuWaitTime.mean());
			System.out.println("StdDev.cpu wait time:"+cpuWaitTime.stdDev());
			System.out.println("StdDev. CPU Queue size:"+cpuQueueSize.stdDev());
			System.out.println("Mean Execution Time Transaction:"+executionTxTime.mean());
			System.out.println("StdDev. Execution Time Transaction:"+executionTxTime.stdDev());
			System.out.println("Max Execution Time Transaction:"+executionTxTime.max());
			System.out.print("------\nSize of Transactions:\n");sizeOfTransactions.print();
			System.out.println("------");
			System.out.println("Num OptDelivered:"+numOptdelivered.sum());
			System.out.println("Num FinalDelivered:"+numFinalDelivered.sum());
			System.out.println("Num Committed:"+numCommitted.sum());
			System.out.println("Number of Aborted transactions: "+numAborted.sum());
			System.out.println("Number of Final Delivery before complete transaction: "+finalDeliveryBeforeComplete.sum());
			System.out.println("Number of Committed transaction at complete time: "+committedWhenComplete.sum());
			System.out.println("Number of Committed transaction when arrive final delivery: "+committedAtTOTime.sum());
			System.out.println("Number of complete runs : "+numberOfExcludedTransactions.sum());
			System.out.println("Number of Aborted transactions: "+numAborted.sum());
			System.out.println("Number of Aborted transactions after reordering: "+numAbortAfterReordering.mean());
			System.out.println("Number of Out of Order deliveries: "+numOutOfOrder.sum());
			System.out.println("Number of safe committed transactions: "+safe.sum());
			
			
			for(int i=0;i<numCPUs;i++){
				System.out.println("CPU"+i+" usage:"+cpusUsage[i].timeAverage());
				meanCpusUsage.setValue(cpusUsage[i].timeAverage());
			}
			System.out.println("Mean CPU Usage:"+meanCpusUsage.mean());
			/*
			//script per verificare i dataitem + poloari e la coda sui dataitem
			Map<Object, TimeVariance> ccTvs = processes[0].getManager().getCcQueue().getCcListsVariance();
			ccTVWrapper[] array_ccTvs = new ccTVWrapper[ccTvs.keySet().size()]; 
			int j=0;
			for(Object otv : ccTvs.keySet()){
				array_ccTvs[j] = new ccTVWrapper(otv,ccTvs.get(otv));
				j++;
			}
			Sort.quicksort(array_ccTvs);
			for(int i=array_ccTvs.length-11;i>0 && i<array_ccTvs.length;i++){
				if(array_ccTvs[i] != null)
					System.out.println("ccConflict Id: "+array_ccTvs[i].id+" Max: "+array_ccTvs[i].tv.max()+";Mean: "+array_ccTvs[i].tv.timeAverage());
			}  
			 */
			if(!simBlocked){
				Sort.quicksort(totalOrderNetwork.total);
				Variance numUnordered = new Variance();
			    Variance unorderedLenth = new Variance();
			    int len = 0;
			    
			    for(int k=0;k<totalOrderNetwork.total.length;k++){
			    	for(int y=k-1;y>=0 && totalOrderNetwork.total[y].ab>totalOrderNetwork.total[k].opt ;y--)
				    	if(totalOrderNetwork.total[y].opt > totalOrderNetwork.total[k].opt)
				    		len++;
			    	if(len != 0){
			    		numUnordered.setValue(1);
			    		unorderedLenth.setValue(len);
			    	}
			    	len = 0;
			    }
			    System.out.println("Num Final Delivery unordered: "+(numUnordered.sum()/totalOrderNetwork.total.length)*100+"%");
			    System.out.println("Mean length of Final Delivery unordered: "+unorderedLenth.mean());
			}else{
				System.out.println("SIMULATION TERMINATED BECAUSE BLOCKED");
			}
			totalOrderNetwork.finished();
			for(int i=0; i<processes.length; i++)
				processes[i].finished();
			System.exit(0);
			SimulationProcess.mainResume();

		} catch (SimulationException e) {
			e.printStackTrace();
		} catch (RestartException e) {
			e.printStackTrace();
		}
	}

	public void processFinished(){
		//System.out.println("Process finished");
		finishedProcesses++;
	}
	
	public void Await ()
	{
		this.Resume();
		SimulationProcess.mainSuspend();
	}
	private class ccTVWrapper implements Comparable{
		public Object id;
		public TimeVariance tv;
		
		public ccTVWrapper(Object id, TimeVariance tv) { 
			this.id = id;
			this.tv = tv;
		}
		
		public int compareTo(Object o) {
			ccTVWrapper o2 = (ccTVWrapper)o;
			if(tv.timeAverage() < o2.tv.timeAverage())
				return -1;
			else if(tv.timeAverage() == o2.tv.timeAverage())
				return 0;
			else
				return 1;
		}
		
	}
}
