package javasim;

public enum DeliveryState {
	OPT_DELIVERED,
	COMMITTABLE,
	FINAL_DELIVERED;
}
