package javasim;

import memory.Memory;

import org.apache.log4j.Logger;

import arjuna.JavaSim.Simulation.RestartException;
import arjuna.JavaSim.Simulation.SimulationException;
import arjuna.JavaSim.Simulation.SimulationProcess;

/**
 * This class represents a replica of the replicated system.
 * This Process joins the total order network and creates the threads that will issue transactions.
 * It also creates a "transaction manager", that contains the logic of the protocol.
 * @author nuno
 *
 */
public class TransactionalProcess extends SimulationProcess implements Sender, Destination{

	private Logger log = Logger.getLogger(TransactionalProcess.class);
	
	private TransactionalSource[] sources;
	private TransactionManager manager;
	private Controller controller;
	private int processID, finishedSources=0,numSources;
	private boolean finished = false;
	private Memory memory = new Memory(PropertyReader.getInt("max_memory"));
	private String managerClassName = PropertyReader.getString("protocol_manager");
	public int xactID=0;
	private Network totalOrderChannel;

	public TransactionalProcess(int id, int numSources, 
			Class<? extends TransactionalSource> sourceClass, 
			int numCPUs, Network network, Controller contr){
		processID = id;
		this.numSources = numSources;
		controller = contr;
		totalOrderChannel = network;
		totalOrderChannel.join(this);
		sources = new TransactionalSource[numSources];
		for(int i=0; i<sources.length; i++){
			try {
				sources[i] = sourceClass.newInstance();
				sources[i].init(i, this, memory);
				sources[i].Activate();
			} catch (SimulationException e) {
				e.printStackTrace();
			} catch (RestartException e) {
				e.printStackTrace();
			} catch (InstantiationException e) {
				e.printStackTrace();
			} catch (IllegalAccessException e) {
				e.printStackTrace();
			}
		}
		log.info("Using the manager: "+managerClassName);
		try {
			manager = (TransactionManager) Class.forName(managerClassName).newInstance();
			manager.init(this, numCPUs);
			manager.Activate();
		} catch (SimulationException e) {
			e.printStackTrace();
		} catch (RestartException e) {
			e.printStackTrace();
		} catch (InstantiationException e) {
			throw new RuntimeException("Unable to create the TransactionManager instance",e);
		} catch (IllegalAccessException e) {
			throw new RuntimeException("Unable to create the TransactionManager instance",e);
		} catch (ClassNotFoundException e) {
			throw new RuntimeException("Unable to create the TransactionManager instance",e);
		}
	}
	
	public void sourceFinished(){
		finishedSources++;
		try {
			Activate();
		} catch (SimulationException e) {
			e.printStackTrace();
		} catch (RestartException e) {
			e.printStackTrace();
		}
	}
	
	public int getProcessID() {
		return processID;
	}

	public void sendMessage(Transaction tx,boolean inBatch) {
		totalOrderChannel.sendMsg(tx,inBatch);
	}

	public void deliver(Transaction tx) {
		if(tx.isOptimistic())
			manager.optDelivery(tx);
		else
			manager.finalDelivery(tx);
	}
	
	@Override
	public void run() {
		while(!finished){
			if(finishedSources >= numSources)
				controller.processFinished();
			try {
				Cancel();
			} catch (RestartException e) {
				e.printStackTrace();
			}
		}
	}

	public void finished() {
		finished=true;
		try {
			for(int i=0; i<sources.length; i++){
				sources[i].terminate();
				if(sources[i].idle())
					sources[i].Activate();
			}
			manager.terminate();
			if(manager.idle())
				manager.Activate();
			totalOrderChannel.leave(this);
			this.terminate();
			if (this.idle()){
				this.Activate(); 
				// just to make its run method end --> is this true also for processes that have a for(;;) loop?
			}
		} catch (SimulationException e) {
			e.printStackTrace();
		} catch (RestartException e) {
			e.printStackTrace();
		}
	}
	
	@Override
	public boolean equals(Object o){
		if(o instanceof TransactionalProcess)
			return processID == ((TransactionalProcess)o).processID;
		else
			return false;
	}
	/**
	 * @return the manager
	 */
	public TransactionManager getManager() {
		return manager;
	}
	
}
