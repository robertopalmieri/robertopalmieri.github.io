package javasim;

import java.util.Random;

public class RandomGenerator {

	private static Random random = new Random(System.currentTimeMillis());
	
	public static int getNextInt(int max){
		return random.nextInt(max);
	}
	
}
