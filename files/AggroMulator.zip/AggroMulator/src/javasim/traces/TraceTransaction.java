/**
 * 
 */
package javasim.traces;

import java.util.ArrayList;
import java.util.List;

import javasim.Controller;
import javasim.DeliveryState;
import javasim.PropertyReader;
import javasim.Sender;
import javasim.TMOperation;
import javasim.Transaction;
import javasim.TransactionState;
import javasim.TransactionalSource;
import javasim.traces.TracedOperation.TracedOperationType;
import memory.Dataitem;
import memory.Memory;

import org.apache.log4j.Logger;

public class TraceTransaction extends Transaction {

	Logger log = Logger.getLogger(TraceTransaction.class);
	
	private List<TMOperation> operations;
	private List<TMOperation> readSet;
	private List<TMOperation> writeSet;
	private double executionTime;
	private boolean commit;
	private Memory memory;
	private int currentOperation;
	private List<TracedOperation> ope;

	/**
	 * @param id
	 * @param proc
	 * @param th
	 * @param mem
	 */
	public TraceTransaction(Object id, Sender proc, TransactionalSource th,
			List<TracedOperation> ops,Memory mem) {
		super(id, proc, th);
		memory = mem;
		ope = ops;
		/*
		for(TracedOperation to : ope){
			if(to.getOperation() == TracedOperationType.READ)
				Controller.numFinalDelivered.setValue(1);
		}
		executionTime = ope.get(ope.size()-2).getTimestamp() - ope.get(0).getTimestamp();
		if(executionTime <0 )
			log.debug("");
		double execution_time_scaling = PropertyReader.getDouble("execution_time_scaling");
		executionTime /= execution_time_scaling;
		if(PropertyReader.getDouble("fixed_execution_time") != 0.0)
			executionTime = PropertyReader.getDouble("fixed_execution_time");
		*/
		readSet = new ArrayList<TMOperation>();
		writeSet = new ArrayList<TMOperation>();
		
		commit = true;
		currentOperation = 0;
		this.operations = new ArrayList<TMOperation>();
		populateMemory();
		Controller.sizeOfTransactions.setValue(ope.size());
		//ope = null;
	}
	
	@Override
	public void execute(){
		log.debug("Tx: "+this.toString()+"holds "+getExecutionTime());
		getCpu().hold(getExecutionTime());
		super.execute();
	}
	
	public void doCommit(){
		return;
		/*
		if(!isCommit())
			return;
		VersionedMemory mem = getMemory();
		long newVersion = mem.getCurrentMemoryVersion()+1;
		for(STMObject obj : writeSet.getObjectSetList()){
			obj.setVersion(newVersion);
			mem.setObject(obj);
		}
		mem.setNewMemoryVersion(newVersion);
		*/
	}

	/*
	 * @see javasim.Transaction#getExecutionTime()
	 */
	@Override
	public double getExecutionTime() {
		return executionTime;
	}

	/*
	 * @see javasim.Transaction#getReadSet()
	 */
	@Override
	public List<TMOperation> getReadSet() {
		return readSet;
	}

	/*
	 * @see javasim.Transaction#getWriteSet()
	 */
	@Override
	public List<TMOperation> getWriteSet() {
		return writeSet;
	}

	/**
	 * @return the commit
	 */
	public boolean isCommit() {
		return commit;
	}
	
	private void populateMemory(){
		for(TracedOperation op : ope){
			if(op.getOperation() == TracedOperationType.READ || op.getOperation() == TracedOperationType.WRITE){
				Dataitem di =  memory.initDataitem(op.getObjID());
				TMOperation tm_op = new TMOperation(di, op.getOperation(),op.getTimestamp());
				operations.add(tm_op);
			}
		}
	}

	@Override
	public void clearReadWriteSet() {
		readSet = null;
		writeSet = null;
		
	}
	public void addTMOperation(TMOperation tm_op){
		//aggiongo solo se non l'ho gi� toccato
		if(tm_op.getOp_type() == TracedOperationType.READ){
			for(TMOperation o : readSet)
				if(o.getDi().equals(tm_op.getDi()))
					return;
			readSet.add(tm_op);
		}
		else if(tm_op.getOp_type() == TracedOperationType.WRITE){
			for(TMOperation o : writeSet)
				if(o.getDi().equals(tm_op.getDi()))
					return;
			writeSet.add(tm_op);
		}
		else
			throw new RuntimeException("Operation not supported");
	}

	public List<TMOperation> getOperations() {
		return operations;
	}

	public int getCurrentOperation() {
		return currentOperation;
	}

	public void incCurrentOperation() {
		this.currentOperation++;
	}

	public Object clone() throws CloneNotSupportedException {
		TraceTransaction new_tx = (TraceTransaction) super.clone();
		new_tx.setState(TransactionState.DELIVERED);
		//new_tx.setDeliveryState(DeliveryState.OPT_DELIVERED);
		new_tx.setDeliveryState(getDeliveryState());
		new_tx.readSet = new ArrayList<TMOperation>();
		new_tx.writeSet = new ArrayList<TMOperation>();
		new_tx.currentOperation = 0;
		new_tx.setCpu(null);
		new_tx.operations = new ArrayList<TMOperation>();
		new_tx.populateMemory();
		return new_tx;
	}
	
}
