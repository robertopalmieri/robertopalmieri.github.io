package javasim.traces;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.util.Date;
import java.util.Random;
import java.util.StringTokenizer;

import javasim.PropertyReader;

import org.apache.log4j.Logger;

import distribution.ABDelay;
import distribution.ABDelay_trace;


public class ABTraceLoader {
	Logger log = Logger.getLogger(ABTraceLoader.class);
	
	private static ABTraceLoader instance=null;
	
	private static RandomAccessFile reader;
	private static File trace_file;
	private static boolean ABtraceFromBegin = PropertyReader.getBoolean("ABTraceFromBegin");
	
	private ABTraceLoader(){}
	
	private ABTraceLoader(String tracefile){
		try {
			reader = new RandomAccessFile(tracefile,"r");
			trace_file = new File(tracefile);
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
	}
	
	private static void boot(){
		instance = new ABTraceLoader(PropertyReader.getString("AB_trace_file"));
		String line = "";
		Random generator = new Random((new Date()).getTime());
		int randomIndex = 0;
		if(ABtraceFromBegin)
			randomIndex = 0;
		else
			randomIndex = generator.nextInt((int) (trace_file.length()));
		
		boolean trovatoRun = false;
		try {
			reader.seek(randomIndex);
		} catch (IOException e) {
			e.printStackTrace();
		}
		while(!trovatoRun){
			try {
				line = reader.readLine();
			} catch (IOException e) {
				e.printStackTrace();
			}
			StringTokenizer tok = new StringTokenizer(line);
			while(tok.hasMoreTokens()){
				if(tok.nextToken().equalsIgnoreCase("ID:"))
					trovatoRun = true;
			}
		}
	}
	
	public static ABTraceLoader instance(){
		if(instance == null)
			boot();
		return instance;
	}
	
	
	public ABDelay getNextABRun(){
		ABDelay run_found = null;
		try {
			String line = reader.readLine();
			if(line == null){
				throw new RuntimeException("ABTraceFile finished");
			}
			StringTokenizer tok = new StringTokenizer(line);
			while(tok.hasMoreTokens()){
				String firtToken = tok.nextToken();
				if(firtToken.equalsIgnoreCase("ID:")){
					run_found = new ABDelay_trace();
					run_found.msg_id = tok.nextToken();
					run_found.sendingTime = Long.parseLong(tok.nextToken());
					run_found.optDelTime = Long.parseLong(tok.nextToken());
					run_found.finalDelTime = Long.parseLong(tok.nextToken());
				}
				else
					throw new RuntimeException("Wrong line in ABTraceFile");
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
		return run_found;
	}
}
