/**
 * 
 */
package javasim.traces;

import java.util.List;

import javasim.PropertyReader;
import javasim.Sender;
import javasim.TransactionalProcess;
import javasim.TransactionalSource;
import arjuna.JavaSim.Simulation.RestartException;

/**
 * @author nonius
 *
 */
public class TraceSource extends TransactionalSource {

	public TraceSource() {
		super();
	}

	@Override
	public void run() {
		log.debug("Started source: "+TraceSource.class.getName()+" with ID: "+getSourceID());
		Sender process = getProcess();
		TraceLoader loader = TraceLoader.instance();
		List<TracedOperation> xactOps = null;
		List<TracedOperation> xactOpsTemp = null;
		boolean transactions_finished = false;
		boolean inBatch = false;
		for(int i=0;i<(numTotalTransactions/numMsgBatching); i++){
			//thik time
			if(think_time_source != 0){
				try {
					Hold(expTTDistrb.getNumber());
				} catch (Exception e1) {
					e1.printStackTrace();
				}
			}
			inBatch = false;
			for(int j=0;j<numMsgBatching; j++){
				if(PropertyReader.getBoolean("megalock")){
					xactOps = loader.getFakeNextTransaction();
					if(PropertyReader.getDouble("fixed_execution_time") == 0){
						xactOpsTemp = loader.getNextTransaction();
						if(xactOpsTemp == null){
							transactions_finished = true;
							break;
						}
						xactOps.get(xactOps.size()-2).setTimestamp(xactOpsTemp.get(xactOpsTemp.size()-2).getTimestamp());
						xactOps.get(xactOps.size()-1).setTimestamp(xactOpsTemp.get(xactOpsTemp.size()-1).getTimestamp());
						xactOps.get(0).setTimestamp(xactOpsTemp.get(0).getTimestamp());
					}
				}else{
					xactOps = loader.getNextTransaction();
				}
				if(xactOps == null){
					//transactions_finished = true;
					//traccia ciclica
					loader = TraceLoader.restartTrace();
					j--;
					continue;
					//break;
				}
				//TraceTransaction tx = new TraceTransaction(xactOps.get(0).getXactID(),process,this,getMemory(),xactOps);
				TraceTransaction tx = new TraceTransaction(((TransactionalProcess)process).xactID++,process,this,xactOps,getMemory());
				if(log.isDebugEnabled())
					log.debug("Sending transaction "+tx);
				process.sendMessage(tx,inBatch);
				inBatch = true;
			}
			if(transactions_finished){
				log.info("Transactions finisched");
				log.info("Last Transaction: "+ ((TransactionalProcess)process).xactID);
				break;
			}
			if(typeOfABDistribution != 3){
				try {
					double waitToAttend = expTRateDistrb.getNumber(); 
					Hold(waitToAttend);
				} catch (Exception e1) {
					e1.printStackTrace();
				}
			}
		}
		process.sourceFinished();
		log.debug("Source finished");
		try {
			// waits until the simulation is finished
			Cancel();
		} catch (RestartException e) {
			e.printStackTrace();
		}
	}
	
}
