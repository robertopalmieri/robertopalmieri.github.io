package javasim.traces;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Random;
import java.util.StringTokenizer;

import javasim.Controller;
import javasim.PropertyReader;
import javasim.traces.TracedOperation.TracedOperationType;

import org.apache.log4j.Logger;

import arjuna.JavaSim.Statistics.PrecisionHistogram;

public class TraceLoader {
	Logger log = Logger.getLogger(TraceLoader.class);
	
	private static TraceLoader instance=null;
	
	private static RandomAccessFile reader;
	private static File trace_file;
	private long initialTime = -1;
	//private Random randGC;
	private static boolean TXtraceFromBegin = PropertyReader.getBoolean("TXTraceFromBegin");
	private static int SkippedTransaction = PropertyReader.getInt("SkippedTransaction");
	private static boolean TraceInMicro = PropertyReader.getBoolean("tracciaMicro");
	
	private TraceLoader(){}
	
	private TraceLoader(String tracefile){
		try {
			//reader = new BufferedReader(new FileReader(tracefile));
			//randGC = new Random();
			reader = new RandomAccessFile(tracefile,"r");
			trace_file = new File(tracefile);
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
	}
	
	public static void boot(){
		instance = new TraceLoader(PropertyReader.getString("trace_file"));
		String line = "";
		Random generator = new Random((new Date()).getTime());
		int randomIndex = 0;
		if(TXtraceFromBegin)
			randomIndex = 0;
		else
			randomIndex = generator.nextInt((int) (trace_file.length()));
		System.out.println("RANDOM INDEX "+randomIndex);
		//randomIndex = 391275832;
		//if(randomIndex != 0){
			boolean trovatoRun = false;
			try {
				reader.seek(randomIndex);
			} catch (IOException e) {
				e.printStackTrace();
			}
			int cont = 0;
			while(cont<SkippedTransaction){
				try {
					line = reader.readLine();
				} catch (IOException e) {
					e.printStackTrace();
				}
				cont++;
			}
			while(!trovatoRun){
				try {
					line = reader.readLine();
				} catch (IOException e) {
					e.printStackTrace();
				}
				StringTokenizer tok = new StringTokenizer(line);
				while(tok.hasMoreTokens()){
					if(tok.nextToken().equalsIgnoreCase("C"))
						trovatoRun = true;
				}
			}
		//}
	}
	
	public static TraceLoader instance(){
		if(instance == null)
			boot();
		return instance;
	}
	
	public static TraceLoader restartTrace(){
		boot();
		return instance;
	}
	
	public List<TracedOperation> getNextTransaction(){
		boolean ended=false;
		ArrayList<TracedOperation> list = null;
		double execution_time_scaling = PropertyReader.getDouble("execution_time_scaling");
		try {
			int numWrite = 0;
			initialTime = -1;
			while(!ended){
				String line = reader.readLine();
				if(line == null){
					ended = true;
					log.info("Finished Transactions in trace");
					//System.exit(0);
					return null;
				}
				StringTokenizer tok = new StringTokenizer(line);
				while(tok.hasMoreTokens() && ! ended){
					long lts = 0;
					if(TraceInMicro)
						lts = Long.parseLong(tok.nextToken()) * 1000;
					else
						lts = Long.parseLong(tok.nextToken());
					if(lts <= 0)
						throw new RuntimeException("Durata negativa o zero istruzione");
					if(initialTime<0)
						initialTime=lts;
					double timestamp = (double)(lts-initialTime);
					if(timestamp <= 0){
						timestamp = 1;
						//throw new RuntimeException("Durata negativa o zeros istruzione");
					}
					initialTime=lts;
					//String xactID = tok.nextToken();
					String operation = tok.nextToken();
					String objID = null;
					if(operation.equals("R") || operation.equals("W"))
						objID = tok.nextToken();
					TracedOperationType type = null;
					if(operation.equals("B")){
						type = TracedOperationType.BEGIN;
						list = new ArrayList<TracedOperation>();
					}else if(operation.equals("R"))
						type = TracedOperationType.READ;
					else if(operation.equals("W")){
						type = TracedOperationType.WRITE;
						numWrite++;
					}else if(operation.equals("C"))
						type = TracedOperationType.COMMIT;
					else if(operation.equals("V"))
						type = TracedOperationType.VALIDATION;
					else if(operation.equals("G")){
						type = TracedOperationType.GARBAGE_COLLECTOR;
						break;
					}
					else
						throw new IOException("Wrong operation type while reading the file.");
					TracedOperation trace = null;
					timestamp /= execution_time_scaling;
					if(PropertyReader.getDouble("fixed_execution_time") != 0.0)
						timestamp = PropertyReader.getDouble("fixed_execution_time");
					if(type == TracedOperationType.READ || type == TracedOperationType.WRITE){
						if(timestamp > 100000){
							break;
						}
						trace = new TracedOperation(type,timestamp,objID);
					}
					else
						trace = new TracedOperation(type,timestamp);
					list.add(trace);
					if(type == TracedOperationType.COMMIT || type == TracedOperationType.ABORT){
						if(numWrite != 0){
							double executionTime = list.get(list.size()-2).getTimestamp() - list.get(0).getTimestamp();
							/*
							if(PropertyReader.getBoolean("megalock")){
								if(PropertyReader.getDouble("fixed_execution_time") != 0){
									list.remove(list.size()-1);
									TracedOperation traceMegaLock = new TracedOperation(TracedOperationType.WRITE,timestamp,"1");
									list.add(traceMegaLock);
									list.add(trace);
								}
							}
							*/
							if(executionTime < PropertyReader.getInt("max_lenght_transaction_without_scaling"))
								ended = true;
							else{
								numWrite = 0;
								log.debug("Transaction Too Long");
								list = new ArrayList<TracedOperation>();
								Controller.numberOfExcludedTransactions.setValue(1);
							}
						}
						else{
							log.debug("Transaction ReadOnly Removed");
							list = new ArrayList<TracedOperation>();
						}
					}
				}
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
		return list;
	}
	
	public List<TracedOperation> getFakeNextTransaction(){
		ArrayList<TracedOperation> list = new ArrayList<TracedOperation>();
		list.add(new TracedOperation(TracedOperationType.BEGIN, 0));
		list.add(new TracedOperation(TracedOperationType.READ, 1,"1"));
		list.add(new TracedOperation(TracedOperationType.WRITE, 1,"1"));
		list.add(new TracedOperation(TracedOperationType.VALIDATION, 2));
		list.add(new TracedOperation(TracedOperationType.COMMIT, 3));
		return list;
	}
	
	public static void main(String[] args) throws IOException{
		
		File directory = new File(args[0]);
		File[] files = directory.listFiles();
		TraceLoader loader = null;
		for (int i=0; i<files.length; i++) {
			try{
				String iniz = files[i].getName().substring(0,15);
				//if(!iniz.equals("dstm2.benchmark"))
				//	continue;
			}catch(Exception e){
				continue;
			}
			
			boolean debug=false;

			BufferedReader r = new BufferedReader(new FileReader(files[i]));
			//if (args.length==2 && args[1].compareTo("-D")==0)
			//	debug=true;
			String l;

			int state = 0; // 0 begin not found, 1 begin found
			long initTime=0,endTime=0;
			long skippedXacts=0;
			PrecisionHistogram h=new PrecisionHistogram();
			int initTransactions = 0;
			while ( (l = r.readLine())!=null )  {
				if (debug)
					System.out.println("Processing "+l);
				//else System.out.print(".");
				String time;
				String type;

				StringTokenizer st= new StringTokenizer(l," ");
				time=st.nextToken();
				//st.nextToken(); // skip id
				type=st.nextToken();

				if (state == 0) { 
					if (type.compareToIgnoreCase("B")==0) {
						initTime=Long.parseLong(time);
						state=1;
					}
					else {
						if (debug)
							System.out.println("looking for a begin - skipping"+l);
					}
				}
				else if (state == 1) {
					if (type.compareToIgnoreCase("V")==0) {
						if(initTransactions < 0){
							initTransactions++;
							skippedXacts++;						
							state=0;
							continue;
						}
						endTime=Long.parseLong(time);
						h.setValue(endTime-initTime);
						state=0;
					}
					else {
						//System.out.println("KAZOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOO");
						if (debug)
							System.out.println("looking for a validate - skipping"+l);
						if (type.compareToIgnoreCase("C")==0){
							skippedXacts++;
							state = 0;
						}else if ((type.compareToIgnoreCase("W")==0) || (type.compareToIgnoreCase("R")==0)){
							//READ WRITE
						}else if (type.compareToIgnoreCase("B")==0){
							//Abort
							initTime=Long.parseLong(time);
							state=1;
						}else{
							System.err.println("Non previsto!!");
						}
					}
				}
				else {
					System.err.println("WTF! Unexpected state ");
					System.exit(1);
				}

			}
			System.out.println("Histogram of "+files[i]);
			//h.print();
			System.out.println("Mean: "+h.mean()+"||"+h.numberOfSamples());
			System.out.println("Skipped Xacts:"+skippedXacts);
			r.close();
		}
	}
}
