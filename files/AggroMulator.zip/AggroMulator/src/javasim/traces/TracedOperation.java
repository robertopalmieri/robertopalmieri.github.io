package javasim.traces;

public class TracedOperation {
	public static enum TracedOperationType{
		BEGIN,
		READ,
		WRITE,
		ABORT,
		COMMIT,
		VALIDATION,
		GARBAGE_COLLECTOR
	}
	
	private final TracedOperationType operation;
	//private final String xactID;
	private final String objID;
	//private final double timestamp;
	private double timestamp;
	
	/*
	public TracedOperation(TracedOperationType type, double ts, String xid, String oid){
		operation = type;
		timestamp = ts;
		xactID = xid;
		objID = oid;
	}
	*/
	public TracedOperation(TracedOperationType type, double ts, String oid){
		operation = type;
		timestamp = ts;
		objID = oid;
	}
	
	public TracedOperation(TracedOperationType type, double ts){
		operation = type;
		timestamp = ts;
		//xactID = xid;
		objID = null;
	}

	/**
	 * @return the operation
	 */
	public TracedOperationType getOperation() {
		return operation;
	}

	/**
	 * @return the xactID
	 */
	/*
	public String getXactID() {
		return xactID;
	}
	*/
	/**
	 * @return the objID
	 */
	public String getObjID() {
		return objID;
	}
	
	public double getTimestamp() {
		return timestamp;
	}
	
	public void setTimestamp(double d) {
		timestamp = d;
	}
	
	@Override
	public String toString(){
		return operation+" "+objID;
	}

}
