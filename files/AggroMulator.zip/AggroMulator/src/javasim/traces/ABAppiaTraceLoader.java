package javasim.traces;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.util.Date;
import java.util.Random;
import java.util.StringTokenizer;

import javasim.PropertyReader;

import org.apache.log4j.Logger;

import distribution.ABDelay;
import distribution.ABDelay_appiaTrace;


public class ABAppiaTraceLoader {
	Logger log = Logger.getLogger(ABAppiaTraceLoader.class);
	
	private static ABAppiaTraceLoader instance=null;
	
	private static RandomAccessFile reader;
	private static File trace_file;
	private static boolean ABtraceFromBegin = PropertyReader.getBoolean("ABTraceFromBegin");
	private static String IpSender = PropertyReader.getString("IpSender");
	private static int SkippedAppiaEvent = PropertyReader.getInt("SkippedAppiaEvent");
	
	private ABAppiaTraceLoader(){}
	
	private ABAppiaTraceLoader(String tracefile){
		try {
			reader = new RandomAccessFile(tracefile,"r");
			trace_file = new File(tracefile);
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
	}
	
	private static void boot(){
		instance = new ABAppiaTraceLoader(PropertyReader.getString("AB_trace_file"));
		String line = "";
		Random generator = new Random((new Date()).getTime());
		int randomIndex = 0;
		if(ABtraceFromBegin)
			randomIndex = 0;
		else
			randomIndex = generator.nextInt((int) (trace_file.length()));
		System.out.println("RANDOMI INDEX AB: "+randomIndex);
		boolean trovatoRun = false;
		try {
			reader.seek(randomIndex);
		} catch (IOException e) {
			e.printStackTrace();
		}
		int cont = 0;
		while(cont<SkippedAppiaEvent){
			try {
				line = reader.readLine();
			} catch (IOException e) {
				e.printStackTrace();
			}
			cont++;
		}
		while(!trovatoRun){
			try {
				line = reader.readLine();
			} catch (IOException e) {
				e.printStackTrace();
			}
			StringTokenizer tok = new StringTokenizer(line,",");
			while(tok.hasMoreTokens()){
				if(tok.nextToken().startsWith("/"))
					trovatoRun = true;
			}
		}
	}
	
	public static ABAppiaTraceLoader instance(){
		if(instance == null)
			boot();
		return instance;
	}
	
	
	public ABDelay getNextABRun(){
		ABDelay run_found = null;
		try {
			String line = ""; 
			StringTokenizer tok = null;
			/*
			while(true){
				line = reader.readLine();
				if(line == null){
					throw new RuntimeException("ABTraceFile finished");
				}
				tok = new StringTokenizer(line,",");
				String firtToken = tok.nextToken();
				int a =firtToken.indexOf("/");
				int b = firtToken.indexOf(":");
				String aux = firtToken.substring(a+1, b);
				//if(aux.equalsIgnoreCase(IpSender)){
				//	break;
				//}
			}
			*/
			line = reader.readLine();
			if(line == null){
				throw new RuntimeException("ABTraceFile finished");
			}
			tok = new StringTokenizer(line,",");
			//while(tok.hasMoreTokens()){
				//String firtToken = tok.nextToken();
				//if(firtToken.equalsIgnoreCase("ID:")){
					run_found = new ABDelay_appiaTrace();
					String firtToken = tok.nextToken();
					int a =firtToken.indexOf("/");
					int b = firtToken.indexOf(":");
					run_found.msg_id = firtToken.substring(a+1, b);
					run_found.sendingTime = Double.parseDouble(tok.nextToken());
					run_found.optDelTime = Double.parseDouble(tok.nextToken());
					run_found.finalDelTime = Double.parseDouble(tok.nextToken());
					//System.out.println(run_found.sendingTime+","+run_found.optDelTime+","+run_found.finalDelTime);
				//}
				//else
				//	throw new RuntimeException("Wrong line in ABTraceFile");
			//}
		} catch (IOException e) {
			e.printStackTrace();
		}
		return run_found;
	}
}
