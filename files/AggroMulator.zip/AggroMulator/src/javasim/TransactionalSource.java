package javasim;

import memory.Memory;

import org.apache.log4j.Logger;

import arjuna.JavaSim.Distributions.ExponentialStream;
import arjuna.JavaSim.Simulation.SimulationProcess;

/**
 * this class represents a thread in a replica. It issues transactions to the system.
 * Each new transaction is issued only when it receives a notification indicating that the previous
 * transaction has finished. 
 * @author nuno
 *
 */
public abstract class TransactionalSource extends SimulationProcess{

	protected Logger log = Logger.getLogger(TransactionalSource.class);
	
	private Sender process;
	private int sourceID;
	public final int typeOfABDistribution=PropertyReader.getInt("ABDistribution");
	public int numTotalTransactions = PropertyReader.getInt("total_transactions");
	public int transactions_rate = PropertyReader.getInt("transactions_rate");
	public double think_time_source = PropertyReader.getDouble("think_time_source");
	public int numMsgBatching = PropertyReader.getInt("baching");
	private Memory memory;
	public ExponentialStream expTTDistrb;
	public ExponentialStream expTRateDistrb;
	
	public void init(int id, Sender proc,Memory mem){
		sourceID = id;
		process = proc;
		expTTDistrb = new ExponentialStream(think_time_source);
		//double tx_freq = 1 / ((double)transactions_rate);
		expTRateDistrb = new ExponentialStream(transactions_rate);
		memory = mem;
	}
	
	public abstract void run();
	
	/*
	public void transactionFinished(Transaction tx){
		try {
			this.Activate();
		} catch (SimulationException e) {
			e.printStackTrace();
		} catch (RestartException e) {
			e.printStackTrace();
		}
	}
	*/
	
	public int getSourceID() {
		return sourceID;
	}
	
	public Memory getMemory() {
		return memory;
	}
	
	public Sender getProcess() {
		return process;
	}

	public void setSourceID(int sourceID) {
		this.sourceID = sourceID;
	}
	
}
