package javasim;

public enum TransactionState {
	STARTED,
	DELIVERED,
	ACTIVE, //tx active quando esce dal transaction manager ed enta nella coda di cpu
	EXECUTING,
	EXECUTED, 
	ABORTING,
	COMMITTED,
}
