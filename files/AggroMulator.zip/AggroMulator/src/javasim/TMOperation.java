package javasim;

import javasim.traces.TracedOperation.TracedOperationType;
import memory.Dataitem;

public class TMOperation {
	private Dataitem di;
	private TracedOperationType op_type;
	private double timeToOp;
	private Transaction readFrom;
	
	public TMOperation(Dataitem di, TracedOperationType opType,double time) {
		super();
		this.di = di;
		op_type = opType;
		timeToOp = time;
		readFrom = null;
	}
	public Dataitem getDi() {
		return di;
	}
	public void setDi(Dataitem di) {
		this.di = di;
	}
	public TracedOperationType getOp_type() {
		return op_type;
	}
	public void setOp_type(TracedOperationType opType) {
		op_type = opType;
	}
	public double getTimeToOp() {
		return timeToOp;
	}
	public void setTimeToOp(double timeToOp) {
		this.timeToOp = timeToOp;
	}
	public Transaction getReadFrom() {
		return readFrom;
	}
	public void setReadFrom(Transaction readFrom) {
		this.readFrom = readFrom;
	}
}
