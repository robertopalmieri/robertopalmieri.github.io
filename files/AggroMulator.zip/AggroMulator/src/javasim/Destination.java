package javasim;

public interface Destination {

	void deliver(Transaction tx);
	
	
}
