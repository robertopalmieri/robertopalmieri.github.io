package javasim;
import generatorABTrace.Wrapper;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.PriorityQueue;

import javasim.traces.TraceTransaction;

import org.apache.log4j.Logger;

import arjuna.JavaSim.Simulation.RestartException;
import arjuna.JavaSim.Simulation.SimulationException;
import arjuna.JavaSim.Simulation.SimulationProcess;
import distribution.ABDelay;
import distribution.ABDelay_appiaTrace;
import distribution.ABDelay_deterministic;
import distribution.ABDelay_erlang;
import distribution.ABDelay_trace;

/**
 * This class represents the Atomic Broadcast. Processes (replicas) should join this network
 * and send messages through this object to all the (joined) processes.
 * @author nuno
 *
 */
public class Network extends SimulationProcess {

	Logger log = Logger.getLogger(Network.class);
	
	private PriorityQueue<Transaction> queue;
	public boolean finished=false;
	public String description;
	private ArrayList<Destination> view;
	private final int typeOfABDistribution=PropertyReader.getInt("ABDistribution");
	private final boolean deliverOptimistic=PropertyReader.getBoolean("deliver_optimistic");
	private ABDelay ABDistribution;
	private long globalOrder=0;
	private int count_mgsId = 0;
	private double lastOAB = 0;
	private double lastFAB = 0;
	
	public Wrapper[] total = new Wrapper[PropertyReader.getInt("total_transactions")];
	

	/**
	 * Creates a network
	 * @param desc
	 */
	public Network(String desc) {
		description=desc;
		queue=new PriorityQueue<Transaction>(100, new FinalTimestampComparator());
		view = new ArrayList<Destination>();
		
		switch(typeOfABDistribution){
			case 0	:	ABDistribution = new ABDelay_deterministic();break;
			case 1	:	ABDistribution = new ABDelay_erlang();break;
			case 2	:	ABDistribution = new ABDelay_trace();break;
			case 3	:	ABDistribution = new ABDelay_appiaTrace();break;
			default	:	throw new RuntimeException("Error in type of distribution");
		}
	}

	/**
	 * sends a messages (transaction) to all the joined processes.
	 * @param m
	 */
	public void sendMsg(Transaction m,boolean inBatch) {
		if(typeOfABDistribution == 3){
			sendMsgFromTrace(m, inBatch);
			return;
		}
		try {
			double current = CurrentTime();
			double currentOAB = 0;
			double currentFAB = 0;
			if(inBatch){
				currentOAB = lastOAB;
				currentFAB = lastFAB;
			}else{
				currentOAB = ABDistribution.getOptDeliveryTime();
				currentFAB = ABDistribution.getFinalDeliveryTime();
				lastFAB = currentFAB;
				lastOAB = currentOAB;
			}
			double finalTime = current+currentFAB;
			double optTime = current+currentOAB;
			total[count_mgsId] = new Wrapper(count_mgsId++, optTime, finalTime);
			m.setGlobalOrder(globalOrder++);
			m.setOptimistic(deliverOptimistic);
			m.setStatsBeginTime(CurrentTime());
			m.setDeliveryTimes(optTime, finalTime);
			if(log.isDebugEnabled())
				log.debug("sending message "+m+" at "+current);
			queue.add(m);
			if (this.evtime()<=0 || this.evtime()>m.getDeliveryTime()){
				this.ReActivateAt(m.getDeliveryTime());
			}
		} catch (SimulationException e) {
			e.printStackTrace();
		} catch (RestartException e) {
			e.printStackTrace();
		} catch (ArithmeticException e) {
			e.printStackTrace();
		}
	}

	public void sendMsgFromTrace(Transaction m,boolean inBatch) {
		try {
			double currentOAB = 0;
			double currentFAB = 0;
			double sendingTime = 0;
			if(inBatch){
				currentOAB = lastOAB;
				currentFAB = lastFAB;
			}else{
				currentOAB = (ABDistribution.getOptDeliveryTime() * 1000);
				sendingTime = (ABDistribution.getSendingTime() * 1000);
				currentFAB = (ABDistribution.getFinalDeliveryTime() * 1000);
				lastFAB = currentFAB;
				lastOAB = currentOAB;
			}
			double finalTime = currentFAB;
			double optTime = currentOAB;
			total[count_mgsId] = new Wrapper(count_mgsId++, optTime, finalTime);
			m.msgId = ABDistribution.getMsgId();
			m.setGlobalOrder(globalOrder++);
			m.setOptimistic(deliverOptimistic);
			m.setStatsBeginTime(sendingTime);
			m.setDeliveryTimes(optTime, finalTime);
			log.info("sending message "+m+" at "+sendingTime);
			queue.add(m);
			if (this.evtime()<=0 || this.evtime()>m.getDeliveryTime()){
				this.ReActivateAt(m.getDeliveryTime());
			}
		} catch (SimulationException e) {
			e.printStackTrace();
		} catch (RestartException e) {
			e.printStackTrace();
		} catch (ArithmeticException e) {
			e.printStackTrace();
		}
	}
	
	@Override
	public void run() {
		if(log.isDebugEnabled())
			log.debug("Network started");

		while (!finished) {
			Transaction tx;
			while (!queue.isEmpty() && queue.peek().getDeliveryTime()==CurrentTime()) {
				tx=queue.poll();
				//if(log.isDebugEnabled())
				if(tx.isOptimistic())
					log.debug("Opt-Delivering message "+tx+" to all processes at "+CurrentTime());
				else
					log.debug("Final-Delivering message "+tx+" to all processes at "+CurrentTime());
				for(Destination dest : view){
					if(dest.equals(tx.getProcess()))
						dest.deliver(tx);
					else
						dest.deliver(tx.cloneMe());
				}
				if(tx.isOptimistic()){
					try {
						//Faccio la clone quando si materializza l'esigenza nella final delivery
						TraceTransaction tx2 = (TraceTransaction)tx;
						Transaction finalTx;
						finalTx = (Transaction) tx2.clone();
						//Transaction finalTx = tx;
						finalTx.setOptimistic(false);
						queue.add(finalTx);
					} catch (CloneNotSupportedException e) {
						e.printStackTrace();
					}
				}
			}

			try {
				if ((tx=queue.peek())!=null)
					this.ReActivateAt(tx.getDeliveryTime());
				else
					Cancel();
			} catch (SimulationException e) {
				e.printStackTrace();
			} catch (RestartException e) {
				e.printStackTrace();
			}
		}
	}
	
	public void finished() {
		finished=true;
		this.terminate();
		/*
		if (this.idle())
			try {
				this.Activate(); // just to make its run method end
			} catch (SimulationException e) {
				e.printStackTrace();
			} catch (RestartException e) {
				e.printStackTrace();
			}
		*/
	}
	
	/**
	 * add a process to the current "View"
	 * @param dest
	 */
	public void join(Destination dest){
		view.add(dest);
	}

	/**
	 * removes a process from the current "View"
	 * @param dest
	 */
	public void leave(Destination dest){
		view.remove(dest);
	}

	/**
	 * class used to impose an order on the messages queue.
	 * the Transaction.getDeliveryTime() returns a different value, depending if the transaction should be optimistically
	 * delivered, or it is being scheduled for the final delivery.
	 * @author nuno
	 *
	 */
	class FinalTimestampComparator implements Comparator<Transaction> {
		public int compare(Transaction o1, Transaction o2) {
			int timeOrder = new Double(o1.getDeliveryTime()).compareTo(new Double(o2.getDeliveryTime()));
			return (timeOrder == 0)? new Long(o1.getGlobalOrder()).compareTo(new Long(o2.getGlobalOrder())) : timeOrder;
		}
	};	
}
