package javasim;

public interface Sender {
	int getProcessID();
	void sendMessage(Transaction tx,boolean inBatching);
	void sourceFinished();
}
