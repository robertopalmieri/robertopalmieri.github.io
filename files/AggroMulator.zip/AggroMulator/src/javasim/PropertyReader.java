package javasim;

import java.io.IOException;
import java.io.InputStream;
import java.net.URL;
import java.util.Properties;

public class PropertyReader {

	private static String propsFile = "/config.properties";
	private static Properties props = null;

	private PropertyReader(){}

	private static void boot(){
		if(props == null){
			try {
				readProperties();
			} catch (IOException e) {
				throw new RuntimeException(e);
			}
		}
	}

	private static void readProperties() throws IOException{
		props = new Properties();
		URL props_url = PropertyReader.class.getResource(propsFile);
		if(props_url == null)
			throw new IOException("Could not find properties file: "+propsFile);
		InputStream is = props_url.openStream();
		props.load(is);
		is.close();
	}
	
	public static void setPropertiesFile(String newPropsFile){
		propsFile = newPropsFile;
		boot();
	}
	
	public static String getString(String prop){
		return props.getProperty(prop);
	}
	
	public static int getInt(String prop){
		return Integer.parseInt(props.getProperty(prop));
	}
	
	public static void setProperty(String prop, String value){
		props.setProperty(prop, value);
	}

	public static long getLong(String prop){
		return Long.parseLong(props.getProperty(prop));
	}
	
	public static double getDouble(String prop){
		return Double.parseDouble(props.getProperty(prop));
	}

	public static boolean getBoolean(String prop){
		return Boolean.parseBoolean(props.getProperty(prop));
	}
}
