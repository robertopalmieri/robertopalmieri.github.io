package javasim;

import arjuna.JavaSim.Simulation.SimulationProcess;

/**
 * this class represents the logic of the protocol.
 * it receives transactions and executes them using a pool of CPUs,
 * by the order defined by the total order.
 * 
 * @author nuno
 *
 */
public abstract class TransactionManager extends SimulationProcess {

	public abstract void init(TransactionalProcess proc, int numberOfCPUs);

	/**
	 * Called by the CPU, after executing a transaction.
	 * @param tx the executed transaction
	 */
	public abstract void deliverCompleteTransaction(Transaction tx);

	/**
	 * Called by the process (replica) to deliver a transaction received optimistically.
	 * @param tx
	 */
	public abstract void optDelivery(Transaction tx);

	/**
	/**
	 * Called by the process (replica) to deliver a transaction (final delivery).
	 * This method adds the new transaction to the conflict class queues.
	 * @param tx
	 */
	public abstract void finalDelivery(Transaction tx);

	/**
	 * Called by its creator to finish the simulation.
	 */
	public abstract void finish();

	/**
	 * Gets the corresponding process (replica) instance.
	 * @return the process
	 */
	public abstract TransactionalProcess getProcess();
	
}