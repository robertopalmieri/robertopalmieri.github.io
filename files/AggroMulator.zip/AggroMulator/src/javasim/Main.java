package javasim;

import org.apache.log4j.Logger;

public class Main {
	
	public static void main (String[] args){

		final Logger log = Logger.getLogger(Main.class);
		
		if(args.length == 0){
			System.err.println("Missing args!");
			System.exit(-1);
		}
		else{
			log.info("Using properties file: "+args[0]);
			PropertyReader.setPropertiesFile(args[0]);
		}
		if(args.length >= 2){
			PropertyReader.setProperty("abcast_optimistic_time", args[1]);
			PropertyReader.setProperty("abcast_final_time", args[2]);
			PropertyReader.setProperty("transactions_rate", args[3]);
			PropertyReader.setProperty("fixed_execution_time", args[4]);
			PropertyReader.setProperty("isAggressive", args[5]);
			PropertyReader.setProperty("baching", args[6]);
			PropertyReader.setProperty("num_sources", "1");
			//int numSr = Integer.parseInt(args[3]);
			//int totTx = PropertyReader.getInt("total_transactions");
			//int tx_per_th = totTx / numSr;
			//PropertyReader.setProperty("num_transactions",""+tx_per_th);
		}

		Controller c = new Controller();
		c.Await();
		System.exit(0);
	}



	
}
