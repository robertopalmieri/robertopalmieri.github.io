package javasim;

import java.util.ArrayList;
import java.util.List;

import javasim.aggrostatemachine.AggroStateMachineTransactionManager;
import javasim.traces.TraceTransaction;
import javasim.traces.TracedOperation;
import javasim.traces.TracedOperation.TracedOperationType;
import memory.Dataitem;

import org.apache.log4j.Logger;

import arjuna.JavaSim.Simulation.RestartException;
import arjuna.JavaSim.Simulation.SimulationException;
import arjuna.JavaSim.Simulation.SimulationProcess;

/**
 * This class represents a CPU that belongs to a replica.
 * This is managed by the TransactionManager, which is responsible to give transactions for
 * these CPUs to execute them.
 */
public class CPU extends SimulationProcess {

	private Logger log = Logger.getLogger(CPU.class);
	
	private AggroStateMachineTransactionManager manager;
	private TraceTransaction transaction;
	private int cpuID;
	//private TimeVariance cpuUsage;
	private boolean isInWait;
	private TMOperation currentOperation = null;
	
	public CPU(AggroStateMachineTransactionManager m, int id){
		manager = m;
		cpuID = id;
		isInWait = false;
	}
	
	public void run(){
		try {
			Cancel();
		} catch (RestartException e) {
			e.printStackTrace();
		}
		while(true){
			if(transaction != null){
				log.debug("CPU executing transaction for "+transaction.getExecutionTime()+" time ticks.");
				transaction.setStartProcessing(CurrentTime());
				if(((Integer)transaction.getXactID()).intValue() == 128)
					log.debug("");
				List<TMOperation> operations = transaction.getOperations();
				for(TMOperation op : operations){
					if(((Integer)transaction.getXactID()).intValue() == 128)
						log.debug("");
					if(transaction.getState() == TransactionState.ABORTING){
						log.debug("Transaction aborted while executin in cpu");
						break;
					}
					currentOperation = op;
					if(transaction.getCurrentOperation() == 4851 && ((Integer)transaction.getXactID()).intValue() == 100){
						log.debug("");
					}
					if(op.getOp_type() == TracedOperationType.READ){
						//execute read
						int retry = -1;
						Transaction readFrom = null;
						if(AggroStateMachineTransactionManager.containsInTMOperations(transaction.getReadSet(), op) == null && AggroStateMachineTransactionManager.containsInTMOperations(transaction.getWriteSet(), op) == null){
							if(transaction.safe){
								Transaction tcom = new TraceTransaction(op.getDi().getLastWriterCommitted(),null,null,new ArrayList<TracedOperation>(),null);
								tcom.setDeliveryState(DeliveryState.FINAL_DELIVERED);
								tcom.setState(TransactionState.COMMITTED);
								readFrom = tcom;
							}else{
								while(true){
									if(((Integer)transaction.getXactID()).intValue() == 100)
										log.debug("");
									//log.debug("Transaction "+transaction+" execute operation "+op.getDi()+"|"+op.getOp_type()+"|"+retry);
									isInWait = false;
									retry++;
									//forse non serve perch� posso controllare direttamente la situazione del dataitem a cui voglio accedere
									List<Transaction> opt_del = manager.getOptDeliveredXAct();
									int pos = 0;
									int i = 0;
									boolean trovato = false;
									boolean opt_delivetared = false;
									Dataitem found = null;
									for(pos=0;pos<opt_del.size();pos++)
										if(opt_del.get(pos).equals(transaction)){
											opt_delivetared = true;
											break;
										}
									for(i=pos-1;i>=0 && opt_delivetared;i--)
										if((found=AggroStateMachineTransactionManager.containsInTMOperations(opt_del.get(i).getWriteSet(), op)) != null){
											trovato = true;
											break;
										}
									if(trovato){
										if(opt_del.get(i).getState() == TransactionState.EXECUTING){
											//Dataitem in working
											Controller.numDIWorking.setValue(1);
											isInWait = true;
											if(((Integer)transaction.getXactID()).intValue() == 100)
												log.debug("");
											try {
												Cancel();
											} catch (RestartException e) {
												e.printStackTrace();
											}
											if(transaction.getState() == TransactionState.ABORTING){
												log.debug("Transaction aborted while executin in cpu");
												break;
											}
										}else if(opt_del.get(i).getState() == TransactionState.EXECUTED){
											//OK posso continuare, dataitem in complete
											//@@@@@ aggiungo la dipendenza al read form set!!!
											readFrom = opt_del.get(i);
											Controller.numDIComplete.setValue(1);
											break;
										}else{
											//comportamento strano
											throw new RuntimeException("Stato committed su dataitem che dovrebe essere stato scritto");
										}
									}else{
										Controller.numDICommitted.setValue(1);
										if(op.getDi().getLastWriterCommitted() != -1){
											Transaction Tc = new TraceTransaction(op.getDi().getLastWriterCommitted(),null,null,new ArrayList<TracedOperation>(),null);
											Tc.setDeliveryState(DeliveryState.FINAL_DELIVERED);
											Tc.setState(TransactionState.COMMITTED);
											readFrom = Tc;
										}else{	
											readFrom = AggroStateMachineTransactionManager.Tc;
										}
										break;
									}
								}
								if(transaction.getState() == TransactionState.ABORTING){
									break;
								}
							}
							//prima era dopo la parentesi
							op.setReadFrom(readFrom);
							transaction.addTMOperation(op);
						}
						transaction.incCurrentOperation();
						if(readFrom == null)
							log.debug("");
						hold(op.getTimeToOp());
					}else if(op.getOp_type() == TracedOperationType.WRITE){
						//execute write
						if(AggroStateMachineTransactionManager.containsInTMOperations(transaction.getWriteSet(), op) == null){
							//log.debug("Transaction "+transaction+" execute operation "+op.getDi()+"|"+op.getOp_type());
							//early abort!!!
							List<Transaction> opt_del = manager.getOptDeliveredXAct();
							int pos=0;
							int i = 0;
							List<Transaction> txs_to_abort = new ArrayList<Transaction>();
							for(pos=0;pos<opt_del.size();pos++)
								if(opt_del.get(pos).equals(transaction))
									break;
							for(i=pos+1;i<opt_del.size();i++)
								if((AggroStateMachineTransactionManager.containsInTMOperations(opt_del.get(i).getReadSet(), op)) != null){
									//questa � una vera e propria abort perch� la tx ha gi� letto qualcosa quindi � stat in CPU!!
									txs_to_abort.add(opt_del.get(i));
								}
							if(!txs_to_abort.isEmpty())
								//chiedo di abortire le transazioni
								manager.abortTransactions(txs_to_abort);
						}
						transaction.incCurrentOperation();
						transaction.addTMOperation(op);
						hold(op.getTimeToOp());
					}
				}
				if(transaction.getState() !=TransactionState.ABORTING){
					manager.deliverCompleteTransaction(transaction);
				}
				transaction.setCpu(null);
				transaction = null;	
			}
			try {
				Cancel();
			} catch (RestartException e) {
				e.printStackTrace();
			}
		}
	}
	
	public void hold(double time){
		try {
			Controller.cpusUsage[cpuID].setValue(1.0);
			Hold(time);
			Controller.cpusUsage[cpuID].setValue(0);
		} catch (SimulationException e) {
			e.printStackTrace();
		} catch (RestartException e) {
			e.printStackTrace();
		}
	}
	
	public boolean executeTransaction(Transaction tx){
		TraceTransaction ttx = (TraceTransaction)tx;
		if(transaction != null)
			throw new RuntimeException("CPU Busy....cannot be used to execute a new transaction");
			//return false;
		transaction = ttx;
		transaction.setCpu(this);
		try {
			Activate();
		} catch (SimulationException e) {
			e.printStackTrace();
		} catch (RestartException e) {
			e.printStackTrace();
		}
		return true;
	}
	
	public boolean isBusy(){
		return transaction != null;
	}
	
	public boolean isInWait(){
		return isInWait;
	}
	
	@Override
	public String toString(){
		return "CPU "+cpuID+"<"+isBusy()+";"+transaction+">";
	}

	public Transaction getTransaction() {
		return transaction;
	}
	
	public TMOperation getCurrentOperation() {
		return currentOperation;
	}
}
